-- CoolAir Technician Booking Platform — Schema v2 (adds accounts: customers, admins)
-- IMPORTANT: this replaces the earlier schema. If you already ran the old schema.sql,
-- drop the old database first (DROP DATABASE coolair;) then import this file fresh.

CREATE DATABASE IF NOT EXISTS coolair CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE coolair;

-- ---------------------------------------------------------------
-- Customer accounts
-- ---------------------------------------------------------------
CREATE TABLE customers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  phone VARCHAR(30),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ---------------------------------------------------------------
-- Admin accounts
-- ---------------------------------------------------------------
CREATE TABLE admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ---------------------------------------------------------------
-- Services offered (Cleaning, Repair, Installation, Maintenance...)
-- ---------------------------------------------------------------
CREATE TABLE services (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(50) NOT NULL UNIQUE
);

-- ---------------------------------------------------------------
-- Technicians
-- ---------------------------------------------------------------
CREATE TABLE technicians (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  specialty VARCHAR(150),
  years_experience INT DEFAULT 0,
  service_area VARCHAR(150),
  starting_fee DECIMAL(10,2) DEFAULT 0,
  avatar_initials VARCHAR(4) DEFAULT '??',
  avatar_color VARCHAR(10) DEFAULT '#0F4C75',
  is_verified TINYINT(1) DEFAULT 0,
  background_checked TINYINT(1) DEFAULT 0,
  rating DECIMAL(2,1) DEFAULT 0,
  review_count INT DEFAULT 0,
  distance_km DECIMAL(4,1) DEFAULT 0,
  availability ENUM('available_now','scheduled','offline') DEFAULT 'available_now',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Many-to-many: which services each technician offers
CREATE TABLE technician_services (
  technician_id INT NOT NULL,
  service_id INT NOT NULL,
  PRIMARY KEY (technician_id, service_id),
  FOREIGN KEY (technician_id) REFERENCES technicians(id) ON DELETE CASCADE,
  FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE CASCADE
);

-- ---------------------------------------------------------------
-- Bookings — now tied to a customer account
-- ---------------------------------------------------------------
CREATE TABLE bookings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  booking_ref VARCHAR(20) NOT NULL UNIQUE,
  customer_id INT NOT NULL,
  technician_id INT NOT NULL,
  service_id INT NOT NULL,
  customer_name VARCHAR(100) NOT NULL,
  customer_phone VARCHAR(30),
  address TEXT NOT NULL,
  schedule_date DATE NOT NULL,
  schedule_time VARCHAR(50) NOT NULL,
  problem_description TEXT,
  estimated_min DECIMAL(10,2),
  estimated_max DECIMAL(10,2),
  final_price DECIMAL(10,2) DEFAULT NULL,
  status ENUM('pending','accepted','declined','on_the_way','arrived','in_progress','completed','cancelled') NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (customer_id) REFERENCES customers(id),
  FOREIGN KEY (technician_id) REFERENCES technicians(id),
  FOREIGN KEY (service_id) REFERENCES services(id)
);

-- ---------------------------------------------------------------
-- Reviews — one per completed booking (booking_id NULL allowed for
-- older/seeded reviews that weren't tied to a specific booking)
-- ---------------------------------------------------------------
CREATE TABLE reviews (
  id INT AUTO_INCREMENT PRIMARY KEY,
  technician_id INT NOT NULL,
  booking_id INT NULL,
  customer_name VARCHAR(100) NOT NULL,
  rating TINYINT NOT NULL,
  comment TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (technician_id) REFERENCES technicians(id) ON DELETE CASCADE,
  FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE SET NULL,
  UNIQUE KEY uniq_booking_review (booking_id)
);

-- ---------------------------------------------------------------
-- Status history, so the tracking page can show a real timeline
-- ---------------------------------------------------------------
CREATE TABLE booking_status_log (
  id INT AUTO_INCREMENT PRIMARY KEY,
  booking_id INT NOT NULL,
  status VARCHAR(30) NOT NULL,
  changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE
);

-- ---------------------------------------------------------------
-- Login throttling / lockout after repeated failed logins
-- ---------------------------------------------------------------
CREATE TABLE login_throttle (
  id INT AUTO_INCREMENT PRIMARY KEY,
  role ENUM('admin','technician','customer') NOT NULL,
  email VARCHAR(100) NOT NULL,
  fail_count INT NOT NULL DEFAULT 0,
  locked_until DATETIME NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_role_email (role, email)
);

-- ---------------------------------------------------------------
-- Admin activity log — records sensitive admin actions for accountability
-- ---------------------------------------------------------------
CREATE TABLE admin_activity_log (
  id INT AUTO_INCREMENT PRIMARY KEY,
  admin_id INT NOT NULL,
  action VARCHAR(100) NOT NULL,
  details TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (admin_id) REFERENCES admins(id) ON DELETE CASCADE
);

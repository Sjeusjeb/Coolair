<?php
// Run this ONCE in your browser after importing schema.sql:
//   http://localhost/coolair/database/seed.php
// It inserts demo services, technicians, an admin account, a demo customer
// account, technician-offered services, and sample reviews.

require __DIR__ . '/../config/db.php';

$existing = $pdo->query("SELECT COUNT(*) AS c FROM services")->fetch()['c'];
if ($existing > 0) {
    die("Seed data already present (services table is not empty). Nothing to do. " .
        "If you want to reseed, empty the tables first (or drop and re-import schema.sql).");
}

$pdo->beginTransaction();

try {
    // ---- Services ----
    $services = ['Cleaning', 'Repair', 'Installation', 'Maintenance', 'Freon Refill'];
    $serviceIds = [];
    $stmt = $pdo->prepare("INSERT INTO services (name) VALUES (?)");
    foreach ($services as $s) {
        $stmt->execute([$s]);
        $serviceIds[$s] = $pdo->lastInsertId();
    }

    // ---- Admin account ----
    // Demo login: admin@coolair.demo / admin123
    $adminHash = password_hash('admin123', PASSWORD_DEFAULT);
    $pdo->prepare("INSERT INTO admins (name, email, password) VALUES (?,?,?)")
        ->execute(['CoolAir Admin', 'admin@coolair.demo', $adminHash]);

    // ---- Demo customer account ----
    // Demo login: maria@coolair.demo / password123
    $customerHash = password_hash('password123', PASSWORD_DEFAULT);
    $pdo->prepare("INSERT INTO customers (name, email, password, phone) VALUES (?,?,?,?)")
        ->execute(['Marisol Tan', 'maria@coolair.demo', $customerHash, '0917 123 4567']);

    // ---- Technicians ----
    // Demo login password for ALL technicians below: password123
    $demoHash = password_hash('password123', PASSWORD_DEFAULT);

    $technicians = [
        [
            'name' => 'Juan Dela Cruz',
            'email' => 'juan@coolair.demo',
            'specialty' => 'Aircon Specialist · Split-type & inverter',
            'years_experience' => 6,
            'service_area' => 'Biñan, Laguna',
            'starting_fee' => 450,
            'avatar_initials' => 'JD',
            'avatar_color' => '#0F4C75',
            'is_verified' => 1,
            'background_checked' => 1,
            'rating' => 4.9,
            'review_count' => 212,
            'distance_km' => 1.2,
            'availability' => 'available_now',
            'services' => ['Cleaning', 'Repair', 'Installation', 'Freon Refill'],
        ],
        [
            'name' => 'Mark Villanueva',
            'email' => 'mark@coolair.demo',
            'specialty' => 'HVAC Technician · Commercial units',
            'years_experience' => 8,
            'service_area' => 'Biñan, Laguna',
            'starting_fee' => 500,
            'avatar_initials' => 'MV',
            'avatar_color' => '#3ABEFF',
            'is_verified' => 1,
            'background_checked' => 1,
            'rating' => 4.8,
            'review_count' => 167,
            'distance_km' => 2.4,
            'availability' => 'available_now',
            'services' => ['Repair', 'Installation', 'Maintenance'],
        ],
        [
            'name' => 'Rico Santos',
            'email' => 'rico@coolair.demo',
            'specialty' => 'Aircon Cleaning & Maintenance',
            'years_experience' => 3,
            'service_area' => 'Santa Rosa, Laguna',
            'starting_fee' => 350,
            'avatar_initials' => 'RS',
            'avatar_color' => '#F5A623',
            'is_verified' => 1,
            'background_checked' => 0,
            'rating' => 4.7,
            'review_count' => 94,
            'distance_km' => 3.1,
            'availability' => 'scheduled',
            'services' => ['Cleaning', 'Maintenance'],
        ],
        [
            'name' => 'Liza Ong',
            'email' => 'liza@coolair.demo',
            'specialty' => 'Residential Aircon Cleaning',
            'years_experience' => 4,
            'service_area' => 'Biñan, Laguna',
            'starting_fee' => 380,
            'avatar_initials' => 'LO',
            'avatar_color' => '#1F9D6B',
            'is_verified' => 1,
            'background_checked' => 1,
            'rating' => 4.9,
            'review_count' => 138,
            'distance_km' => 1.8,
            'availability' => 'available_now',
            'services' => ['Cleaning', 'Maintenance', 'Freon Refill'],
        ],
    ];

    $techStmt = $pdo->prepare(
        "INSERT INTO technicians
            (name, email, password, specialty, years_experience, service_area, starting_fee,
             avatar_initials, avatar_color, is_verified, background_checked, rating, review_count,
             distance_km, availability)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
    );
    $techServiceStmt = $pdo->prepare(
        "INSERT INTO technician_services (technician_id, service_id) VALUES (?,?)"
    );

    $techIds = [];
    foreach ($technicians as $t) {
        $techStmt->execute([
            $t['name'], $t['email'], $demoHash, $t['specialty'], $t['years_experience'],
            $t['service_area'], $t['starting_fee'], $t['avatar_initials'], $t['avatar_color'],
            $t['is_verified'], $t['background_checked'], $t['rating'], $t['review_count'],
            $t['distance_km'], $t['availability'],
        ]);
        $id = $pdo->lastInsertId();
        $techIds[$t['name']] = $id;
        foreach ($t['services'] as $sName) {
            $techServiceStmt->execute([$id, $serviceIds[$sName]]);
        }
    }

    // ---- Reviews ----
    $reviews = [
        ['Juan Dela Cruz', 'Angela R.', 5, 'Dumating on time, malinis magtrabaho. Ayos yung split-type namin ngayon.'],
        ['Juan Dela Cruz', 'Paolo M.', 5, 'Explained the issue clearly before starting the repair. Fair yung pricing.'],
        ['Mark Villanueva', 'Ferdie C.', 5, 'Handled our office units well. Professional and quick.'],
        ['Rico Santos', 'Bea L.', 4, 'Good cleaning job, medyo late lang ng konti.'],
        ['Liza Ong', 'Jun T.', 5, 'Very thorough cleaning, explained maintenance tips too.'],
    ];
    $reviewStmt = $pdo->prepare(
        "INSERT INTO reviews (technician_id, customer_name, rating, comment) VALUES (?,?,?,?)"
    );
    foreach ($reviews as $r) {
        $reviewStmt->execute([$techIds[$r[0]], $r[1], $r[2], $r[3]]);
    }

    $pdo->commit();
    echo "Seed data inserted successfully.<br><br>";
    echo "<b>Admin login:</b> admin@coolair.demo / admin123<br>";
    echo "<b>Customer login:</b> maria@coolair.demo / password123<br>";
    echo "<b>Technician logins</b> (all use password: password123):<ul>";
    foreach ($technicians as $t) {
        echo "<li>{$t['email']}</li>";
    }
    echo "</ul><a href='../index.php'>Go to the site</a>";
} catch (Exception $e) {
    $pdo->rollBack();
    die('Seeding failed: ' . htmlspecialchars($e->getMessage()));
}

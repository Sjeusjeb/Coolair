-- ================================================================
-- CoolAir — Supabase (PostgreSQL) schema
-- Run this ONCE in your Supabase project's SQL Editor
-- (supabase.com -> your project -> SQL Editor -> New query -> paste -> Run)
--
-- This recreates the same tables as the old MySQL schema.sql, adapted
-- for Postgres, plus a few helper functions (RPC) that the PHP app
-- calls for things plain REST can't do alone (grouped counts, weekly
-- revenue, recomputing a technician's average rating).
--
-- The app talks to Supabase using the service_role key from
-- server-side PHP only, which bypasses Row Level Security entirely —
-- so RLS is intentionally left OFF below. Never expose the
-- service_role key to the browser.
-- ================================================================

-- ---------------------------------------------------------------
-- Customer accounts
-- ---------------------------------------------------------------
create table if not exists customers (
  id bigint generated always as identity primary key,
  name text not null,
  email text not null unique,
  password text not null,
  phone text,
  created_at timestamptz not null default now()
);

-- ---------------------------------------------------------------
-- Admin accounts
-- ---------------------------------------------------------------
create table if not exists admins (
  id bigint generated always as identity primary key,
  name text not null,
  email text not null unique,
  password text not null,
  created_at timestamptz not null default now()
);

-- ---------------------------------------------------------------
-- Services offered (Cleaning, Repair, Installation, Maintenance...)
-- ---------------------------------------------------------------
create table if not exists services (
  id bigint generated always as identity primary key,
  name text not null unique
);

-- ---------------------------------------------------------------
-- Technicians
-- ---------------------------------------------------------------
create table if not exists technicians (
  id bigint generated always as identity primary key,
  name text not null,
  email text not null unique,
  password text not null,
  specialty text,
  years_experience int not null default 0,
  service_area text,
  starting_fee numeric(10,2) not null default 0,
  avatar_initials text not null default '??',
  avatar_color text not null default '#0F4C75',
  is_verified boolean not null default false,
  background_checked boolean not null default false,
  rating numeric(2,1) not null default 0,
  review_count int not null default 0,
  distance_km numeric(4,1) not null default 0,
  availability text not null default 'available_now'
    check (availability in ('available_now','scheduled','offline')),
  created_at timestamptz not null default now()
);

-- Many-to-many: which services each technician offers
create table if not exists technician_services (
  technician_id bigint not null references technicians(id) on delete cascade,
  service_id bigint not null references services(id) on delete cascade,
  primary key (technician_id, service_id)
);

-- ---------------------------------------------------------------
-- Bookings — tied to a customer account
-- ---------------------------------------------------------------
create table if not exists bookings (
  id bigint generated always as identity primary key,
  booking_ref text not null unique,
  customer_id bigint not null references customers(id),
  technician_id bigint not null references technicians(id),
  service_id bigint not null references services(id),
  customer_name text not null,
  customer_phone text,
  address text not null,
  schedule_date date not null,
  schedule_time text not null,
  problem_description text,
  estimated_min numeric(10,2),
  estimated_max numeric(10,2),
  final_price numeric(10,2),
  status text not null default 'pending'
    check (status in ('pending','accepted','declined','on_the_way','arrived','in_progress','completed','cancelled')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Postgres has no "ON UPDATE CURRENT_TIMESTAMP" — a trigger does the job
create or replace function set_updated_at() returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists trg_bookings_updated_at on bookings;
create trigger trg_bookings_updated_at
  before update on bookings
  for each row execute function set_updated_at();

-- ---------------------------------------------------------------
-- Reviews — one per completed booking (booking_id NULL allowed for
-- older/seeded reviews that weren't tied to a specific booking)
-- ---------------------------------------------------------------
create table if not exists reviews (
  id bigint generated always as identity primary key,
  technician_id bigint not null references technicians(id) on delete cascade,
  booking_id bigint unique references bookings(id) on delete set null,
  customer_name text not null,
  rating smallint not null,
  comment text,
  created_at timestamptz not null default now()
);

-- ---------------------------------------------------------------
-- Status history, so the tracking page can show a real timeline
-- ---------------------------------------------------------------
create table if not exists booking_status_log (
  id bigint generated always as identity primary key,
  booking_id bigint not null references bookings(id) on delete cascade,
  status text not null,
  changed_at timestamptz not null default now()
);

-- ---------------------------------------------------------------
-- Login throttling / lockout after repeated failed logins
-- ---------------------------------------------------------------
create table if not exists login_throttle (
  id bigint generated always as identity primary key,
  role text not null check (role in ('admin','technician','customer')),
  email text not null,
  fail_count int not null default 0,
  locked_until timestamptz,
  updated_at timestamptz not null default now(),
  unique (role, email)
);

-- ---------------------------------------------------------------
-- Admin activity log — records sensitive admin actions for accountability
-- ---------------------------------------------------------------
create table if not exists admin_activity_log (
  id bigint generated always as identity primary key,
  admin_id bigint not null references admins(id) on delete cascade,
  action text not null,
  details text,
  created_at timestamptz not null default now()
);

-- ================================================================
-- RPC helper functions — called from PHP via
-- POST https://<project>.supabase.co/rest/v1/rpc/<function_name>
-- ================================================================

-- Admin dashboard: totals + this week's revenue in one round trip
create or replace function admin_dashboard_stats()
returns table (
  total_technicians bigint,
  total_customers bigint,
  total_bookings bigint,
  revenue_this_week numeric
) language sql as $$
  select
    (select count(*) from technicians),
    (select count(*) from customers),
    (select count(*) from bookings),
    (select coalesce(sum(coalesce(final_price, estimated_max)), 0)
       from bookings
      where status = 'completed'
        and date_trunc('week', updated_at) = date_trunc('week', now()));
$$;

-- Admin dashboard: bookings grouped by status
create or replace function booking_status_counts()
returns table (status text, c bigint)
language sql as $$
  select status, count(*) as c from bookings group by status;
$$;

-- Admin customers list, with each customer's booking count
create or replace function customers_with_booking_counts()
returns table (
  id bigint, name text, email text, phone text, created_at timestamptz, booking_count bigint
) language sql as $$
  select c.id, c.name, c.email, c.phone, c.created_at, count(b.id) as booking_count
  from customers c
  left join bookings b on b.customer_id = c.id
  group by c.id
  order by c.created_at desc;
$$;

-- Technician dashboard: this week's completed-job earnings
create or replace function technician_earnings(p_technician_id bigint)
returns table (jobs bigint, total numeric, avg_price numeric)
language sql as $$
  select
    count(*),
    coalesce(sum(coalesce(final_price, estimated_max)), 0),
    coalesce(avg(coalesce(final_price, estimated_max)), 0)
  from bookings
  where technician_id = p_technician_id
    and status = 'completed'
    and date_trunc('week', updated_at) = date_trunc('week', now());
$$;

-- Recompute a technician's aggregate rating + review_count from their reviews
create or replace function recompute_technician_rating(p_technician_id bigint)
returns void language plpgsql as $$
declare
  v_avg numeric;
  v_cnt bigint;
begin
  select round(avg(rating)::numeric, 1), count(*) into v_avg, v_cnt
  from reviews where technician_id = p_technician_id;

  update technicians
     set rating = coalesce(v_avg, 0),
         review_count = coalesce(v_cnt, 0)
   where id = p_technician_id;
end;
$$;

-- Toggle a technician's is_verified flag
create or replace function toggle_technician_verified(p_technician_id bigint)
returns void language sql as $$
  update technicians set is_verified = not is_verified where id = p_technician_id;
$$;

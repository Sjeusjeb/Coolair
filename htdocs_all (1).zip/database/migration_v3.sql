-- CoolAir — Migration: ratings, login security, admin activity log
-- Safe to run on your EXISTING database — this does NOT drop or recreate
-- anything you already have. It only adds new columns/tables.
--
-- HOW TO RUN: phpMyAdmin -> select the "coolair" database -> SQL tab ->
-- paste this whole file -> Go.
--
-- If you ever run this a second time and see errors like "Duplicate column
-- name" or "Duplicate key name" or "Table already exists" — that's fine,
-- it just means this migration was already applied. Safe to ignore.

USE coolair;

-- ---------------------------------------------------------------
-- 1. Let customers rate a specific completed booking (one rating per
--    booking, prevents rating the same job twice)
-- ---------------------------------------------------------------
ALTER TABLE reviews ADD COLUMN booking_id INT NULL AFTER technician_id;
ALTER TABLE reviews ADD UNIQUE KEY uniq_booking_review (booking_id);
ALTER TABLE reviews ADD CONSTRAINT fk_reviews_booking
  FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE SET NULL;

-- ---------------------------------------------------------------
-- 2. Login throttling / lockout after repeated failed logins
--    (used by customer, technician, and admin login pages)
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS login_throttle (
  id INT AUTO_INCREMENT PRIMARY KEY,
  role ENUM('admin','technician','customer') NOT NULL,
  email VARCHAR(100) NOT NULL,
  fail_count INT NOT NULL DEFAULT 0,
  locked_until DATETIME NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_role_email (role, email)
);

-- ---------------------------------------------------------------
-- 3. Admin activity log — records sensitive admin actions for accountability
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS admin_activity_log (
  id INT AUTO_INCREMENT PRIMARY KEY,
  admin_id INT NOT NULL,
  action VARCHAR(100) NOT NULL,
  details TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (admin_id) REFERENCES admins(id) ON DELETE CASCADE
);

<?php
// Run this ONCE after running database/schema_supabase.sql in the Supabase
// SQL Editor. From the command line:
//   php database/seed_supabase.php
// or in a browser:
//   http://localhost/coolair-system/database/seed_supabase.php
// It inserts demo services, technicians, an admin account, a demo customer
// account, technician-offered services, and sample reviews — via the
// Supabase REST API (no direct DB connection needed).

require __DIR__ . '/../config/supabase.php';

$existing = sb_get('services', ['select' => 'id', 'limit' => 1]);
if (!empty($existing)) {
    die("Seed data already present (services table is not empty). Nothing to do. " .
        "If you want to reseed, empty the tables first in the Supabase SQL editor.");
}

try {
    // ---- Services ----
    $serviceNames = ['Cleaning', 'Repair', 'Installation', 'Maintenance', 'Freon Refill'];
    $serviceIds = [];
    foreach ($serviceNames as $s) {
        $row = sb_insert('services', ['name' => $s]);
        $serviceIds[$s] = $row['id'];
    }

    // ---- Admin account ----
    // Demo login: admin@coolair.demo / admin123
    $adminHash = password_hash('admin123', PASSWORD_DEFAULT);
    sb_insert('admins', ['name' => 'CoolAir Admin', 'email' => 'admin@coolair.demo', 'password' => $adminHash]);

    // ---- Demo customer account ----
    // Demo login: maria@coolair.demo / password123
    $customerHash = password_hash('password123', PASSWORD_DEFAULT);
    sb_insert('customers', [
        'name' => 'Marisol Tan', 'email' => 'maria@coolair.demo', 'password' => $customerHash, 'phone' => '0917 123 4567',
    ]);

    // ---- Technicians ----
    // Demo login password for ALL technicians below: password123
    $demoHash = password_hash('password123', PASSWORD_DEFAULT);

    $technicians = [
        [
            'name' => 'Juan Dela Cruz', 'email' => 'juan@coolair.demo',
            'specialty' => 'Aircon Specialist · Split-type & inverter', 'years_experience' => 6,
            'service_area' => 'Biñan, Laguna', 'starting_fee' => 450, 'avatar_initials' => 'JD',
            'avatar_color' => '#0F4C75', 'is_verified' => true, 'background_checked' => true,
            'rating' => 4.9, 'review_count' => 212, 'distance_km' => 1.2, 'availability' => 'available_now',
            'services' => ['Cleaning', 'Repair', 'Installation', 'Freon Refill'],
        ],
        [
            'name' => 'Mark Villanueva', 'email' => 'mark@coolair.demo',
            'specialty' => 'HVAC Technician · Commercial units', 'years_experience' => 8,
            'service_area' => 'Biñan, Laguna', 'starting_fee' => 500, 'avatar_initials' => 'MV',
            'avatar_color' => '#3ABEFF', 'is_verified' => true, 'background_checked' => true,
            'rating' => 4.8, 'review_count' => 167, 'distance_km' => 2.4, 'availability' => 'available_now',
            'services' => ['Repair', 'Installation', 'Maintenance'],
        ],
        [
            'name' => 'Rico Santos', 'email' => 'rico@coolair.demo',
            'specialty' => 'Aircon Cleaning & Maintenance', 'years_experience' => 3,
            'service_area' => 'Santa Rosa, Laguna', 'starting_fee' => 350, 'avatar_initials' => 'RS',
            'avatar_color' => '#F5A623', 'is_verified' => true, 'background_checked' => false,
            'rating' => 4.7, 'review_count' => 94, 'distance_km' => 3.1, 'availability' => 'scheduled',
            'services' => ['Cleaning', 'Maintenance'],
        ],
        [
            'name' => 'Liza Ong', 'email' => 'liza@coolair.demo',
            'specialty' => 'Residential Aircon Cleaning', 'years_experience' => 4,
            'service_area' => 'Biñan, Laguna', 'starting_fee' => 380, 'avatar_initials' => 'LO',
            'avatar_color' => '#1F9D6B', 'is_verified' => true, 'background_checked' => true,
            'rating' => 4.9, 'review_count' => 138, 'distance_km' => 1.8, 'availability' => 'available_now',
            'services' => ['Cleaning', 'Maintenance', 'Freon Refill'],
        ],
    ];

    $techIds = [];
    foreach ($technicians as $t) {
        $row = sb_insert('technicians', [
            'name' => $t['name'], 'email' => $t['email'], 'password' => $demoHash,
            'specialty' => $t['specialty'], 'years_experience' => $t['years_experience'],
            'service_area' => $t['service_area'], 'starting_fee' => $t['starting_fee'],
            'avatar_initials' => $t['avatar_initials'], 'avatar_color' => $t['avatar_color'],
            'is_verified' => $t['is_verified'], 'background_checked' => $t['background_checked'],
            'rating' => $t['rating'], 'review_count' => $t['review_count'],
            'distance_km' => $t['distance_km'], 'availability' => $t['availability'],
        ]);
        $id = $row['id'];
        $techIds[$t['name']] = $id;

        $links = [];
        foreach ($t['services'] as $sName) {
            $links[] = ['technician_id' => $id, 'service_id' => $serviceIds[$sName]];
        }
        sb_insert_many('technician_services', $links);
    }

    // ---- Reviews ----
    $reviews = [
        ['Juan Dela Cruz', 'Angela R.', 5, 'Dumating on time, malinis magtrabaho. Ayos yung split-type namin ngayon.'],
        ['Juan Dela Cruz', 'Paolo M.', 5, 'Explained the issue clearly before starting the repair. Fair yung pricing.'],
        ['Mark Villanueva', 'Ferdie C.', 5, 'Handled our office units well. Professional and quick.'],
        ['Rico Santos', 'Bea L.', 4, 'Good cleaning job, medyo late lang ng konti.'],
        ['Liza Ong', 'Jun T.', 5, 'Very thorough cleaning, explained maintenance tips too.'],
    ];
    foreach ($reviews as $r) {
        sb_insert('reviews', [
            'technician_id' => $techIds[$r[0]], 'customer_name' => $r[1], 'rating' => $r[2], 'comment' => $r[3],
        ]);
    }

    echo "Seed data inserted successfully.\n\n";
    echo "Admin login: admin@coolair.demo / admin123\n";
    echo "Customer login: maria@coolair.demo / password123\n";
    echo "Technician logins (all use password: password123):\n";
    foreach ($technicians as $t) {
        echo "  - {$t['email']}\n";
    }
} catch (SupabaseException $e) {
    die('Seeding failed: ' . $e->getMessage() . "\n");
}

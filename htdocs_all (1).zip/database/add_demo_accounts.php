<?php
// Run this in your browser any time you want to (re)add the demo accounts:
//   http://localhost/coolair-system/database/add_demo_accounts.php
// Unlike seed.php, this checks each record individually (by email/name) and
// only inserts what's missing, so it's safe to run even on a database that
// already has some data in it.

require __DIR__ . '/../config/db.php';

$log = [];

// ---------------------------------------------------------------
// 1. Make sure the base services exist (insert any that are missing)
// ---------------------------------------------------------------
$services = ['Cleaning', 'Repair', 'Installation', 'Maintenance', 'Freon Refill'];
$serviceIds = [];
$checkSvc = $pdo->prepare("SELECT id FROM services WHERE name = ?");
$insertSvc = $pdo->prepare("INSERT INTO services (name) VALUES (?)");

foreach ($services as $s) {
    $checkSvc->execute([$s]);
    $row = $checkSvc->fetch();
    if ($row) {
        $serviceIds[$s] = $row['id'];
    } else {
        $insertSvc->execute([$s]);
        $serviceIds[$s] = $pdo->lastInsertId();
        $log[] = "Added missing service: $s";
    }
}

// ---------------------------------------------------------------
// 2. Admin account — admin@coolair.demo / admin123
// ---------------------------------------------------------------
$checkAdmin = $pdo->prepare("SELECT id FROM admins WHERE email = ?");
$checkAdmin->execute(['admin@coolair.demo']);
if (!$checkAdmin->fetch()) {
    $pdo->prepare("INSERT INTO admins (name, email, password) VALUES (?,?,?)")
        ->execute(['CoolAir Admin', 'admin@coolair.demo', password_hash('admin123', PASSWORD_DEFAULT)]);
    $log[] = "Created admin account: admin@coolair.demo / admin123";
} else {
    $log[] = "Admin account already exists: admin@coolair.demo";
}

// ---------------------------------------------------------------
// 3. Demo customer — maria@coolair.demo / password123
// ---------------------------------------------------------------
$checkCust = $pdo->prepare("SELECT id FROM customers WHERE email = ?");
$checkCust->execute(['maria@coolair.demo']);
if (!$checkCust->fetch()) {
    $pdo->prepare("INSERT INTO customers (name, email, password, phone) VALUES (?,?,?,?)")
        ->execute(['Marisol Tan', 'maria@coolair.demo', password_hash('password123', PASSWORD_DEFAULT), '0917 123 4567']);
    $log[] = "Created customer account: maria@coolair.demo / password123";
} else {
    $log[] = "Customer account already exists: maria@coolair.demo";
}

// ---------------------------------------------------------------
// 4. Demo technicians — all use password123
// ---------------------------------------------------------------
$technicians = [
    [
        'name' => 'Juan Dela Cruz', 'email' => 'juan@coolair.demo',
        'specialty' => 'Aircon Specialist · Split-type & inverter', 'years_experience' => 6,
        'service_area' => 'Biñan, Laguna', 'starting_fee' => 450,
        'avatar_initials' => 'JD', 'avatar_color' => '#0F4C75',
        'is_verified' => 1, 'background_checked' => 1, 'rating' => 4.9, 'review_count' => 212,
        'distance_km' => 1.2, 'availability' => 'available_now',
        'services' => ['Cleaning', 'Repair', 'Installation', 'Freon Refill'],
        'review' => ['Angela R.', 5, 'Dumating on time, malinis magtrabaho. Ayos yung split-type namin ngayon.'],
    ],
    [
        'name' => 'Mark Villanueva', 'email' => 'mark@coolair.demo',
        'specialty' => 'HVAC Technician · Commercial units', 'years_experience' => 8,
        'service_area' => 'Biñan, Laguna', 'starting_fee' => 500,
        'avatar_initials' => 'MV', 'avatar_color' => '#3ABEFF',
        'is_verified' => 1, 'background_checked' => 1, 'rating' => 4.8, 'review_count' => 167,
        'distance_km' => 2.4, 'availability' => 'available_now',
        'services' => ['Repair', 'Installation', 'Maintenance'],
        'review' => ['Ferdie C.', 5, 'Handled our office units well. Professional and quick.'],
    ],
    [
        'name' => 'Rico Santos', 'email' => 'rico@coolair.demo',
        'specialty' => 'Aircon Cleaning & Maintenance', 'years_experience' => 3,
        'service_area' => 'Santa Rosa, Laguna', 'starting_fee' => 350,
        'avatar_initials' => 'RS', 'avatar_color' => '#F5A623',
        'is_verified' => 1, 'background_checked' => 0, 'rating' => 4.7, 'review_count' => 94,
        'distance_km' => 3.1, 'availability' => 'scheduled',
        'services' => ['Cleaning', 'Maintenance'],
        'review' => ['Bea L.', 4, 'Good cleaning job, medyo late lang ng konti.'],
    ],
    [
        'name' => 'Liza Ong', 'email' => 'liza@coolair.demo',
        'specialty' => 'Residential Aircon Cleaning', 'years_experience' => 4,
        'service_area' => 'Biñan, Laguna', 'starting_fee' => 380,
        'avatar_initials' => 'LO', 'avatar_color' => '#1F9D6B',
        'is_verified' => 1, 'background_checked' => 1, 'rating' => 4.9, 'review_count' => 138,
        'distance_km' => 1.8, 'availability' => 'available_now',
        'services' => ['Cleaning', 'Maintenance', 'Freon Refill'],
        'review' => ['Jun T.', 5, 'Very thorough cleaning, explained maintenance tips too.'],
    ],
];

$checkTech = $pdo->prepare("SELECT id FROM technicians WHERE email = ?");
$insertTech = $pdo->prepare(
    "INSERT INTO technicians
        (name, email, password, specialty, years_experience, service_area, starting_fee,
         avatar_initials, avatar_color, is_verified, background_checked, rating, review_count,
         distance_km, availability)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
);
$insertTechService = $pdo->prepare("INSERT INTO technician_services (technician_id, service_id) VALUES (?,?)");
$insertReview = $pdo->prepare("INSERT INTO reviews (technician_id, customer_name, rating, comment) VALUES (?,?,?,?)");
$demoHash = password_hash('password123', PASSWORD_DEFAULT);

foreach ($technicians as $t) {
    $checkTech->execute([$t['email']]);
    if ($checkTech->fetch()) {
        $log[] = "Technician already exists: {$t['email']}";
        continue;
    }

    $insertTech->execute([
        $t['name'], $t['email'], $demoHash, $t['specialty'], $t['years_experience'],
        $t['service_area'], $t['starting_fee'], $t['avatar_initials'], $t['avatar_color'],
        $t['is_verified'], $t['background_checked'], $t['rating'], $t['review_count'],
        $t['distance_km'], $t['availability'],
    ]);
    $techId = $pdo->lastInsertId();

    foreach ($t['services'] as $sName) {
        $insertTechService->execute([$techId, $serviceIds[$sName]]);
    }
    $insertReview->execute([$techId, $t['review'][0], $t['review'][1], $t['review'][2]]);

    $log[] = "Created technician account: {$t['email']} / password123";
}

echo "<h2>Done</h2><ul>";
foreach ($log as $line) {
    echo '<li>' . htmlspecialchars($line) . '</li>';
}
echo "</ul><a href='../index.php'>Go to the site</a>";

-- CoolAir — Add demo accounts (plain SQL, no PHP needed)
-- Works with the current (v3) schema — reviews.booking_id is left NULL for
-- these seeded reviews, which is allowed.
--
-- Passwords are already bcrypt-hashed (the same algorithm PHP's
-- password_hash()/password_verify() use), so login works immediately:
--   Technicians (juan/mark/rico/liza @coolair.demo): password123
--   Admin (admin@coolair.demo): admin123
--   Customer (maria@coolair.demo): password123
--
-- Safe to re-run: uses INSERT IGNORE / NOT EXISTS checks, so running this
-- twice will not create duplicates.
--
-- HOW TO RUN: open phpMyAdmin -> select the "coolair" database -> SQL tab
-- -> paste this whole file -> Go.

USE coolair;

-- ---------------------------------------------------------------
-- Services (technicians need these to exist first)
-- ---------------------------------------------------------------
INSERT IGNORE INTO services (name) VALUES
  ('Cleaning'), ('Repair'), ('Installation'), ('Maintenance'), ('Freon Refill');

-- ---------------------------------------------------------------
-- Admin account:  admin@coolair.demo / admin123
-- ---------------------------------------------------------------
INSERT IGNORE INTO admins (name, email, password) VALUES
  ('CoolAir Admin', 'admin@coolair.demo', '$2b$10$MBW.n9zMXJ6v4GJiVW4YuuUZyqIw3OYu2VjFTVW/AWzuwyYSjavtq');

-- ---------------------------------------------------------------
-- Demo customer account:  maria@coolair.demo / password123
-- ---------------------------------------------------------------
INSERT IGNORE INTO customers (name, email, password, phone) VALUES
  ('Marisol Tan', 'maria@coolair.demo', '$2b$10$7fCLjT6.mosz9WOgIxzaE.l2pOYlWd5ac.i5tHOGbUsF9IuyablnG', '0917 123 4567');

-- ---------------------------------------------------------------
-- Technician accounts — password for all: password123
-- ---------------------------------------------------------------
INSERT IGNORE INTO technicians
  (name, email, password, specialty, years_experience, service_area, starting_fee,
   avatar_initials, avatar_color, is_verified, background_checked, rating, review_count,
   distance_km, availability)
VALUES
  ('Juan Dela Cruz', 'juan@coolair.demo',
   '$2b$10$7fCLjT6.mosz9WOgIxzaE.l2pOYlWd5ac.i5tHOGbUsF9IuyablnG',
   'Aircon Specialist · Split-type & inverter', 6, 'Biñan, Laguna', 450,
   'JD', '#0F4C75', 1, 1, 4.9, 212, 1.2, 'available_now'),

  ('Mark Villanueva', 'mark@coolair.demo',
   '$2b$10$7fCLjT6.mosz9WOgIxzaE.l2pOYlWd5ac.i5tHOGbUsF9IuyablnG',
   'HVAC Technician · Commercial units', 8, 'Biñan, Laguna', 500,
   'MV', '#3ABEFF', 1, 1, 4.8, 167, 2.4, 'available_now'),

  ('Rico Santos', 'rico@coolair.demo',
   '$2b$10$7fCLjT6.mosz9WOgIxzaE.l2pOYlWd5ac.i5tHOGbUsF9IuyablnG',
   'Aircon Cleaning & Maintenance', 3, 'Santa Rosa, Laguna', 350,
   'RS', '#F5A623', 1, 0, 4.7, 94, 3.1, 'scheduled'),

  ('Liza Ong', 'liza@coolair.demo',
   '$2b$10$7fCLjT6.mosz9WOgIxzaE.l2pOYlWd5ac.i5tHOGbUsF9IuyablnG',
   'Residential Aircon Cleaning', 4, 'Biñan, Laguna', 380,
   'LO', '#1F9D6B', 1, 1, 4.9, 138, 1.8, 'available_now');

-- ---------------------------------------------------------------
-- Which services each technician offers
-- ---------------------------------------------------------------
INSERT IGNORE INTO technician_services (technician_id, service_id)
SELECT t.id, s.id FROM technicians t, services s
WHERE t.email = 'juan@coolair.demo' AND s.name IN ('Cleaning','Repair','Installation','Freon Refill');

INSERT IGNORE INTO technician_services (technician_id, service_id)
SELECT t.id, s.id FROM technicians t, services s
WHERE t.email = 'mark@coolair.demo' AND s.name IN ('Repair','Installation','Maintenance');

INSERT IGNORE INTO technician_services (technician_id, service_id)
SELECT t.id, s.id FROM technicians t, services s
WHERE t.email = 'rico@coolair.demo' AND s.name IN ('Cleaning','Maintenance');

INSERT IGNORE INTO technician_services (technician_id, service_id)
SELECT t.id, s.id FROM technicians t, services s
WHERE t.email = 'liza@coolair.demo' AND s.name IN ('Cleaning','Maintenance','Freon Refill');

-- ---------------------------------------------------------------
-- Sample reviews (booking_id left NULL — these aren't tied to a real
-- booking, only inserted if not already present for that technician)
-- ---------------------------------------------------------------
INSERT INTO reviews (technician_id, customer_name, rating, comment)
SELECT t.id, 'Angela R.', 5, 'Dumating on time, malinis magtrabaho. Ayos yung split-type namin ngayon.'
FROM technicians t WHERE t.email = 'juan@coolair.demo'
AND NOT EXISTS (SELECT 1 FROM reviews r WHERE r.technician_id = t.id AND r.customer_name = 'Angela R.');

INSERT INTO reviews (technician_id, customer_name, rating, comment)
SELECT t.id, 'Ferdie C.', 5, 'Handled our office units well. Professional and quick.'
FROM technicians t WHERE t.email = 'mark@coolair.demo'
AND NOT EXISTS (SELECT 1 FROM reviews r WHERE r.technician_id = t.id AND r.customer_name = 'Ferdie C.');

INSERT INTO reviews (technician_id, customer_name, rating, comment)
SELECT t.id, 'Bea L.', 4, 'Good cleaning job, medyo late lang ng konti.'
FROM technicians t WHERE t.email = 'rico@coolair.demo'
AND NOT EXISTS (SELECT 1 FROM reviews r WHERE r.technician_id = t.id AND r.customer_name = 'Bea L.');

INSERT INTO reviews (technician_id, customer_name, rating, comment)
SELECT t.id, 'Jun T.', 5, 'Very thorough cleaning, explained maintenance tips too.'
FROM technicians t WHERE t.email = 'liza@coolair.demo'
AND NOT EXISTS (SELECT 1 FROM reviews r WHERE r.technician_id = t.id AND r.customer_name = 'Jun T.');

-- ================================================================
-- CoolAir — Migration v4: account profile pages (customer + technician)
-- Run ONCE in Supabase SQL Editor (same place you ran the earlier
-- schema_supabase.sql / migration_v3.sql files).
--
-- Adds:
--   - customers.address        (shown/edited on the new profile.php)
--   - customers.avatar_photo   (base64 data URI of the uploaded photo,
--                                nullable — falls back to initials when empty)
--   - technicians.avatar_photo (same idea, for technician/profile.php)
--
-- Photos are stored directly as a base64 data URI in a text column
-- instead of Supabase Storage, so no bucket/policy setup is needed.
-- The app already resizes/compresses the image client-side before
-- upload, and profile_actions.php rejects anything unreasonably large.
-- ================================================================

alter table customers   add column if not exists address text;
alter table customers   add column if not exists avatar_photo text;
alter table technicians add column if not exists avatar_photo text;

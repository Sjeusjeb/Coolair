<?php
// Expects $BASE to be set by the including page:
//   '' for pages in the project root, '../' for pages inside technician/ or admin/
if (!isset($BASE)) { $BASE = ''; }
require_once __DIR__ . '/panel_icons.php';
$role = 'guest';
if (isset($_SESSION['admin_id'])) $role = 'admin';
elseif (isset($_SESSION['technician_id'])) $role = 'technician';
elseif (isset($_SESSION['customer_id'])) $role = 'customer';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo isset($pageTitle) ? htmlspecialchars($pageTitle) . ' — CoolAir' : 'CoolAir'; ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Manrope:wght@500;700;800&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?php echo $BASE; ?>assets/style.css?v=<?php echo @filemtime(__DIR__ . '/../assets/style.css'); ?>">
</head>
<body>

<div class="topnav">
  <a href="<?php echo $BASE; ?>index.php" class="brand">
    <div class="brand-mark">CA</div>
    <div>
      <div class="brand-name">CoolAir</div>
      <div class="brand-sub">Aircon technicians, on demand</div>
    </div>
  </a>
  <button type="button" class="nav-toggle" id="navToggle" aria-label="Open menu" aria-expanded="false">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
  </button>

  <div class="nav-links" id="navLinks">
    <a href="<?php echo $BASE; ?>index.php"><?php echo panel_icon('compass'); ?>Find a technician</a>

    <?php if ($role === 'admin'): ?>
      <a href="<?php echo $BASE; ?>admin/dashboard.php"><?php echo panel_icon('home'); ?>Admin dashboard</a>
      <a href="<?php echo $BASE; ?>admin/logout.php"><?php echo panel_icon('logout'); ?>Log out</a>

    <?php elseif ($role === 'technician'): ?>
      <a href="<?php echo $BASE; ?>technician/dashboard.php"><?php echo panel_icon('home'); ?>Dashboard</a>
      <a href="<?php echo $BASE; ?>technician/profile.php"><?php echo panel_icon('user'); ?>My profile</a>
      <a href="<?php echo $BASE; ?>technician/logout.php"><?php echo panel_icon('logout'); ?>Log out</a>

    <?php elseif ($role === 'customer'): ?>
      <a href="<?php echo $BASE; ?>my-bookings.php"><?php echo panel_icon('wallet'); ?>My bookings</a>
      <a href="<?php echo $BASE; ?>profile.php" style="color:var(--ink-400);"><?php echo panel_icon('user'); ?>Hi, <?php echo htmlspecialchars(explode(' ', $_SESSION['customer_name'])[0]); ?></a>
      <a href="<?php echo $BASE; ?>logout.php"><?php echo panel_icon('logout'); ?>Log out</a>

    <?php else: ?>
      <a href="<?php echo $BASE; ?>login.php"><?php echo panel_icon('user'); ?>Log in</a>
      <a href="<?php echo $BASE; ?>register.php" class="pill"><?php echo panel_icon('plus'); ?>Sign up</a>
      <a href="<?php echo $BASE; ?>technician/login.php" style="font-size:12px;"><?php echo panel_icon('wrench'); ?>Technician</a>
      <a href="<?php echo $BASE; ?>admin/login.php" style="font-size:12px;"><?php echo panel_icon('shield'); ?>Admin</a>
    <?php endif; ?>
  </div>
</div>

<script>
(function(){
  var btn = document.getElementById('navToggle');
  var links = document.getElementById('navLinks');
  if (!btn || !links) return;
  btn.addEventListener('click', function(){
    var open = links.classList.toggle('open');
    btn.setAttribute('aria-expanded', open ? 'true' : 'false');
  });
  links.querySelectorAll('a').forEach(function(a){
    a.addEventListener('click', function(){ links.classList.remove('open'); btn.setAttribute('aria-expanded','false'); });
  });
})();
</script>

<div class="container">

<?php
// Sidebar "panel" layout shared by the admin and technician back-office
// pages. Callers set these variables, then require this file:
//
//   $BASE            '../' (same convention as includes/header.php)
//   $pageTitle       browser tab title
//   $panelRole       'admin' | 'technician'
//   $panelActive     nav key to highlight, e.g. 'dashboard'
//   $panelUserName   display name in the topbar
//   $panelUserSub    role label under the name, e.g. 'Administrator'
//   $panelUserPhoto  optional data-URI avatar photo
//
// config/session.php + config/supabase.php must already be required by
// the caller (same as every other page in the app).
require_once __DIR__ . '/panel_icons.php';

$panelRole      = $panelRole      ?? 'technician';
$panelActive    = $panelActive    ?? '';
$panelUserName  = $panelUserName  ?? 'User';
$panelUserSub   = $panelUserSub   ?? '';
$panelUserPhoto = $panelUserPhoto ?? '';

if ($panelRole === 'admin') {
    $panelBrandName = 'CoolAir';
    $panelBrandSub  = 'Admin Panel';
    $panelNavItems  = [
        ['key' => 'dashboard',    'label' => 'Dashboard',    'icon' => 'home',   'href' => 'admin/dashboard.php'],
        ['key' => 'technicians',  'label' => 'Technicians',  'icon' => 'users',  'href' => 'admin/technicians.php'],
        ['key' => 'bookings',     'label' => 'Bookings',     'icon' => 'wallet', 'href' => 'admin/bookings.php'],
        ['key' => 'customers',    'label' => 'Customers',    'icon' => 'user',   'href' => 'admin/customers.php'],
        ['key' => 'activity',     'label' => 'Activity Log', 'icon' => 'file',   'href' => 'admin/activity_log.php'],
    ];
    $panelLogoutHref = 'admin/logout.php';
} else {
    $panelBrandName = 'CoolAir';
    $panelBrandSub  = 'Technician Panel';
    $panelNavItems  = [
        ['key' => 'dashboard', 'label' => 'Dashboard', 'icon' => 'home',  'href' => 'technician/dashboard.php'],
        ['key' => 'tasks',     'label' => 'My Tasks',  'icon' => 'tasks', 'href' => 'technician/dashboard.php#tasks'],
        ['key' => 'profile',   'label' => 'Profile',   'icon' => 'user',  'href' => 'technician/profile.php'],
    ];
    $panelLogoutHref = 'technician/logout.php';
}

$panelInitials = '';
foreach (explode(' ', trim($panelUserName)) as $w) { if ($w !== '') $panelInitials .= strtoupper($w[0]); }
$panelInitials = substr($panelInitials, 0, 2) ?: '?';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo isset($pageTitle) ? htmlspecialchars($pageTitle) . ' — CoolAir' : 'CoolAir'; ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Manrope:wght@500;700;800&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?php echo $BASE; ?>assets/style.css?v=<?php echo @filemtime(__DIR__ . '/../assets/style.css'); ?>">
</head>
<body>

<div class="panel-shell">
  <header class="panel-topnav">
    <div class="panel-topnav-inner">
      <a href="<?php echo $BASE; ?>index.php" class="panel-brand">
        <div class="panel-brand-mark"><?php echo panel_icon('shield'); ?></div>
        <div>
          <div class="panel-brand-name"><?php echo htmlspecialchars($panelBrandName); ?></div>
          <div class="panel-brand-sub"><?php echo htmlspecialchars($panelBrandSub); ?></div>
        </div>
      </a>

      <div class="panel-nav-divider"></div>

      <nav class="panel-nav-h">
        <?php foreach ($panelNavItems as $item): ?>
          <a href="<?php echo $BASE . $item['href']; ?>" class="<?php echo $panelActive === $item['key'] ? 'on' : ''; ?>">
            <?php echo panel_icon($item['icon']); ?><?php echo htmlspecialchars($item['label']); ?>
          </a>
        <?php endforeach; ?>
      </nav>

      <div class="panel-top-right">
        <div class="panel-user">
          <div class="mini-avatar" style="width:34px;height:34px;font-size:13px;background:var(--blue-900);color:#fff;">
            <?php if (!empty($panelUserPhoto)): ?>
              <img src="<?php echo htmlspecialchars($panelUserPhoto); ?>" alt="">
            <?php else: ?>
              <?php echo htmlspecialchars($panelInitials); ?>
            <?php endif; ?>
          </div>
          <div>
            <div class="panel-user-name"><?php echo htmlspecialchars($panelUserName); ?></div>
            <div class="panel-user-role"><?php echo htmlspecialchars($panelUserSub); ?></div>
          </div>
        </div>
        <a class="panel-logout-btn" href="<?php echo $BASE . $panelLogoutHref; ?>" title="Log out"><?php echo panel_icon('logout'); ?></a>
      </div>
    </div>
  </header>

  <div class="panel-main">
    <div class="panel-content">

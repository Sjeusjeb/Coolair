    </div>
  </div>
</div>
<script>
(function(){
  var eye='<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>';
  var eyeOff='<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>';
  document.querySelectorAll('input[type="password"].field-input:not([readonly])').forEach(function(inp){
    var wrap=document.createElement('div');
    wrap.style.cssText='position:relative;width:100%;';
    inp.parentNode.insertBefore(wrap,inp);wrap.appendChild(inp);
    inp.style.paddingRight='48px';
    var b=document.createElement('button');
    b.type='button';b.innerHTML=eye;b.tabIndex=-1;
    b.setAttribute('aria-label','Show password');
    b.style.cssText='position:absolute;right:8px;top:50%;transform:translateY(-50%);width:34px;height:34px;padding:0;margin:0;border:none;background:transparent;color:#65676b;cursor:pointer;border-radius:50%;display:none;align-items:center;justify-content:center;box-shadow:none;';
    function sync(){b.style.display=(inp.value.length||inp.type==='text')?'flex':'none';}
    inp.addEventListener('input',sync);
    inp.addEventListener('focus',sync);
    b.addEventListener('mouseenter',function(){b.style.background='rgba(0,0,0,0.06)';});
    b.addEventListener('mouseleave',function(){b.style.background='transparent';});
    b.addEventListener('mousedown',function(e){e.preventDefault();});
    b.addEventListener('click',function(){
      var show=inp.type==='password';
      inp.type=show?'text':'password';
      b.innerHTML=show?eyeOff:eye;
      b.setAttribute('aria-label',show?'Hide password':'Show password');
      inp.focus();
    });
    wrap.appendChild(b);
    sync();
  });
})();
</script>
</body>
</html>

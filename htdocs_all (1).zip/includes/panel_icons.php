<?php
// Small line-icon SVGs (stroke-based, currentColor) shared by the admin and
// technician panel layouts. Kept as one function so every sidebar/card icon
// stays visually consistent without pulling in an icon font/library.
function panel_icon(string $name): string
{
    $icons = [
        'home'        => '<path d="M4 11l8-7 8 7"/><path d="M6 10v9h12v-9"/>',
        'tasks'       => '<rect x="5" y="4" width="14" height="17" rx="2"/><path d="M9 2v4M15 2v4M8 11h8M8 15h5"/>',
        'chart'       => '<path d="M4 20V10M11 20V4M18 20v-7"/>',
        'user'        => '<circle cx="12" cy="8" r="3.6"/><path d="M5 20c1.2-4 4.2-6 7-6s5.8 2 7 6"/>',
        'gear'        => '<circle cx="12" cy="12" r="3.2"/><path d="M12 3v2.4M12 18.6V21M4.9 4.9l1.7 1.7M17.4 17.4l1.7 1.7M3 12h2.4M18.6 12H21M4.9 19.1l1.7-1.7M17.4 6.6l1.7-1.7"/>',
        'logout'      => '<path d="M9 4H5v16h4"/><path d="M20 12H10M16 8l4 4-4 4"/>',
        'users'       => '<circle cx="8.5" cy="8" r="3.2"/><path d="M2.5 20c.9-3.5 3.3-5.4 6-5.4s5.1 1.9 6 5.4"/><circle cx="17" cy="8.5" r="2.6"/><path d="M15.7 14.7c2.3.3 4 2 4.7 4.8"/>',
        'wallet'      => '<rect x="3" y="6" width="18" height="13" rx="2"/><path d="M3 10h18"/><circle cx="16.5" cy="14" r="1"/>',
        'file'        => '<path d="M7 3h7l4 4v14H7z"/><path d="M14 3v4h4M9 13h6M9 17h6"/>',
        'search'      => '<circle cx="10.5" cy="10.5" r="6.5"/><path d="M20 20l-4.8-4.8"/>',
        'bell'        => '<path d="M6 9a6 6 0 0112 0c0 5 2 6 2 6H4s2-1 2-6z"/><path d="M10 20a2 2 0 004 0"/>',
        'calendar'    => '<rect x="3.5" y="5" width="17" height="16" rx="2"/><path d="M3.5 10h17M8 3v4M16 3v4"/>',
        'pencil'      => '<path d="M4 20l1-4.2L15.5 5.3a1.5 1.5 0 012.2 0l1 1a1.5 1.5 0 010 2.2L8.2 19 4 20z"/>',
        'camera'      => '<path d="M4 8h3l2-3h6l2 3h3v12H4z"/><circle cx="12" cy="14" r="3.5"/>',
        'mail'        => '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/>',
        'phone'       => '<path d="M5 4h4l1.5 4.5-2.3 1.7a12 12 0 006.6 6.6l1.7-2.3L20 16v4a1 1 0 01-1 1C10 21 3 14 3 5a1 1 0 011-1z"/>',
        'pin'         => '<path d="M12 21s7-6.6 7-11.5A7 7 0 105 9.5C5 14.4 12 21 12 21z"/><circle cx="12" cy="9.3" r="2.4"/>',
        'plus'        => '<path d="M12 5v14M5 12h14"/>',
        'check-circle'=> '<circle cx="12" cy="12" r="9"/><path d="M8 12.5l2.5 2.5L16 9"/>',
        'clock'       => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.5 2"/>',
        'shield'      => '<path d="M12 3l7 3v6c0 4.5-3 7.5-7 9-4-1.5-7-4.5-7-9V6z"/>',
        'eye'         => '<path d="M2 12s3.6-6.5 10-6.5S22 12 22 12s-3.6 6.5-10 6.5S2 12 2 12z"/><circle cx="12" cy="12" r="2.6"/>',
        'trash'       => '<path d="M4 7h16M9 7V5a2 2 0 012-2h2a2 2 0 012 2v2M6 7l1 13h10l1-13"/>',
        // Nav / booking icons
        'compass'     => '<circle cx="12" cy="12" r="9"/><path d="M15.5 8.5l-2.2 5.2-5.2 2.2 2.2-5.2 5.2-2.2z"/>',
        'sparkles'    => '<path d="M12 3l1.4 4.3L18 9l-4.6 1.7L12 15l-1.4-4.3L6 9l4.6-1.7z"/><path d="M19 15l.7 2 2 .7-2 .7-.7 2-.7-2-2-.7 2-.7z"/>',
        'wrench'      => '<path d="M14.7 6.3a4 4 0 10-5.4 5.4L4 17l3 3 5.3-5.3a4 4 0 005.4-5.4l-2.6 2.6-2-2z"/>',
        'box'         => '<path d="M3 8l9-4 9 4-9 4-9-4z"/><path d="M3 8v9l9 4 9-4V8"/><path d="M12 12v9"/>',
        'snowflake'   => '<path d="M12 2v20M4.5 6l15 12M19.5 6l-15 12"/>',
    ];
    $inner = $icons[$name] ?? $icons['home'];
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">' . $inner . '</svg>';
}

<?php
require __DIR__ . '/../config/session.php';
require __DIR__ . '/../config/supabase.php';
require __DIR__ . '/../config/security.php';

$BASE = '../';
$pageTitle = 'My Profile';

if (!isset($_SESSION['technician_id'])) {
    header('Location: login.php');
    exit;
}
$techId = $_SESSION['technician_id'];

$tech = sb_get_one('technicians', ['id' => sb_eq($techId)]);
if (!$tech) {
    header('Location: logout.php');
    exit;
}

$links = sb_get('technician_services', ['select' => 'service_id', 'technician_id' => sb_eq($techId)]);
$myServiceIds = array_column($links, 'service_id');
$allServices  = sb_get('services', ['order' => 'name.asc']);

$completedJobs = sb_count('bookings', ['technician_id' => sb_eq($techId), 'status' => sb_eq('completed')]);
$totalJobs     = sb_count('bookings', ['technician_id' => sb_eq($techId)]);

$activity = sb_get('bookings', [
    'select'        => '*,services(name)',
    'technician_id' => sb_eq($techId),
    'order'         => 'created_at.desc',
    'limit'         => 8,
]);
foreach ($activity as &$b) { $b['service_name'] = $b['services']['name'] ?? ''; }
unset($b);

$statusLabel = [
    'pending'     => 'Request sent',   'accepted'  => 'Accepted',   'declined'    => 'Declined',
    'on_the_way'  => 'On the way',     'arrived'   => 'Arrived',    'in_progress' => 'In progress',
    'completed'   => 'Completed',      'cancelled' => 'Cancelled',
];
$availLabel = ['available_now' => 'Available now', 'scheduled' => 'Scheduled', 'offline' => 'Offline'];

$activeTab = in_array($_GET['tab'] ?? '', ['personal', 'account', 'activity'], true) ? $_GET['tab'] : 'personal';

require __DIR__ . '/../includes/header.php';
?>

<div class="acct-head">
  <h2>My profile</h2>
  <p class="sub">View and manage your technician account</p>
</div>

<?php if (!empty($_GET['msg'])): ?><div class="success-box"><?php echo htmlspecialchars($_GET['msg']); ?></div><?php endif; ?>
<?php if (!empty($_GET['err'])): ?><div class="error-box"><?php echo htmlspecialchars($_GET['err']); ?></div><?php endif; ?>

<div class="card acct-cover">
  <div class="acct-banner">
    <div class="acct-avatar-wrap">
      <div class="acct-avatar" style="background:<?php echo htmlspecialchars($tech['avatar_color']); ?>;">
        <?php if (!empty($tech['avatar_photo'])): ?>
          <img src="<?php echo htmlspecialchars($tech['avatar_photo']); ?>" alt="">
        <?php else: ?>
          <?php echo htmlspecialchars($tech['avatar_initials']); ?>
        <?php endif; ?>
      </div>
      <form method="post" action="profile_actions.php" id="photoForm">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="action" value="update_photo">
        <input type="hidden" name="tab" value="<?php echo htmlspecialchars($activeTab); ?>">
        <input type="hidden" name="avatar_data" id="avatarData">
        <label class="acct-cam-btn" for="avatarInput" title="Change photo">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 8h3l2-3h6l2 3h3v12H4z"/><circle cx="12" cy="14" r="3.5"/></svg>
        </label>
        <input type="file" id="avatarInput" accept="image/*" style="display:none;">
      </form>
    </div>
    <div class="acct-banner-info">
      <div class="acct-name"><?php echo htmlspecialchars($tech['name']); ?></div>
      <div class="acct-role"><?php echo htmlspecialchars($tech['specialty'] ?: 'Technician'); ?></div>
      <span class="verified-tag" style="background:<?php echo $tech['availability'] === 'offline' ? 'var(--line)' : 'var(--green-100)'; ?>;color:<?php echo $tech['availability'] === 'offline' ? 'var(--ink-600)' : 'var(--green-600)'; ?>;">
        <?php echo htmlspecialchars($availLabel[$tech['availability']] ?? $tech['availability']); ?>
      </span>
      <div class="acct-id">Technician ID: TECH-<?php echo str_pad($tech['id'], 4, '0', STR_PAD_LEFT); ?></div>
    </div>
  </div>
</div>

<div class="acct-tabs">
  <button type="button" class="acct-tab <?php echo $activeTab === 'personal' ? 'on' : ''; ?>" data-tab="personal">Personal Information</button>
  <button type="button" class="acct-tab <?php echo $activeTab === 'account' ? 'on' : ''; ?>" data-tab="account">Account Information</button>
  <button type="button" class="acct-tab <?php echo $activeTab === 'activity' ? 'on' : ''; ?>" data-tab="activity">Activity Log</button>
</div>

<!-- Personal Information -->
<div class="acct-panel <?php echo $activeTab === 'personal' ? '' : 'hidden'; ?>" id="panel-personal">
  <div class="card">
    <div class="card-head">
      <h3>Personal Information</h3>
      <button type="button" class="btn-secondary acct-edit-btn" onclick="toggleEdit('form-personal')">Edit Profile</button>
    </div>
    <form method="post" action="profile_actions.php" class="acct-form" id="form-personal">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="action" value="update_profile">

      <label class="field-label">Full name</label>
      <input class="field-input" name="name" value="<?php echo htmlspecialchars($tech['name']); ?>" readonly required>

      <label class="field-label">Email address</label>
      <input class="field-input" value="<?php echo htmlspecialchars($tech['email']); ?>" readonly disabled>

      <label class="field-label">Specialty</label>
      <input class="field-input" name="specialty" value="<?php echo htmlspecialchars($tech['specialty'] ?? ''); ?>" readonly>

      <label class="field-label">Years of experience</label>
      <input class="field-input" type="number" min="0" name="years_experience" value="<?php echo (int)$tech['years_experience']; ?>" readonly>

      <label class="field-label">Service area</label>
      <input class="field-input" name="service_area" value="<?php echo htmlspecialchars($tech['service_area'] ?? ''); ?>" readonly>

      <label class="field-label">Starting fee (₱)</label>
      <input class="field-input" type="number" min="0" step="0.01" name="starting_fee" value="<?php echo htmlspecialchars($tech['starting_fee']); ?>" readonly>

      <label class="field-label">Availability</label>
      <select class="field-select" name="availability" disabled>
        <?php foreach ($availLabel as $val => $label): ?>
          <option value="<?php echo $val; ?>" <?php echo $tech['availability'] === $val ? 'selected' : ''; ?>><?php echo $label; ?></option>
        <?php endforeach; ?>
      </select>

      <label class="field-label">Services offered</label>
      <div class="service-pick">
        <?php foreach ($allServices as $s): $checked = in_array($s['id'], $myServiceIds); ?>
          <label class="service-opt <?php echo $checked ? 'on' : ''; ?>">
            <input type="checkbox" name="service_ids[]" value="<?php echo $s['id']; ?>" disabled <?php echo $checked ? 'checked' : ''; ?>>
            <?php echo htmlspecialchars($s['name']); ?>
          </label>
        <?php endforeach; ?>
      </div>

      <div class="acct-form-actions">
        <button type="submit" class="btn-primary">Save changes</button>
        <button type="button" class="btn-secondary" onclick="cancelEdit('form-personal')">Cancel</button>
      </div>
    </form>
  </div>
</div>

<!-- Account Information -->
<div class="acct-panel <?php echo $activeTab === 'account' ? '' : 'hidden'; ?>" id="panel-account">
  <div class="card">
    <div class="card-head"><h3>Account Information</h3></div>
    <div class="info-row"><span class="k">Username</span><span class="v"><?php echo htmlspecialchars($tech['email']); ?></span></div>
    <div class="info-row"><span class="k">Password</span><span class="v">••••••••</span></div>
    <div class="info-row"><span class="k">Account role</span><span class="v">Technician</span></div>
    <div class="info-row"><span class="k">Rating</span><span class="v"><?php echo number_format($tech['rating'], 1); ?> ★ (<?php echo (int)$tech['review_count']; ?> reviews)</span></div>
    <div class="info-row"><span class="k">Verified</span><span class="v"><?php echo $tech['is_verified'] ? 'Yes' : 'Not yet'; ?></span></div>
    <div class="info-row"><span class="k">Date created</span><span class="v"><?php echo htmlspecialchars(date('F j, Y', strtotime($tech['created_at']))); ?></span></div>
  </div>

  <div class="card">
    <div class="card-head">
      <h3>Change Password</h3>
      <button type="button" class="btn-secondary acct-edit-btn" onclick="toggleEdit('form-password')">Change Password</button>
    </div>
    <form method="post" action="profile_actions.php" class="acct-form" id="form-password">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="action" value="change_password">

      <label class="field-label">Current password</label>
      <input class="field-input" type="password" name="current_password" readonly>

      <label class="field-label">New password</label>
      <input class="field-input" type="password" name="new_password" readonly>

      <label class="field-label">Confirm new password</label>
      <input class="field-input" type="password" name="confirm_password" readonly>

      <div class="acct-form-actions">
        <button type="submit" class="btn-primary">Update password</button>
        <button type="button" class="btn-secondary" onclick="cancelEdit('form-password')">Cancel</button>
      </div>
    </form>
  </div>
</div>

<!-- Activity Log -->
<div class="acct-panel <?php echo $activeTab === 'activity' ? '' : 'hidden'; ?>" id="panel-activity">
  <div class="card">
    <div class="card-head"><h3>Activity Log</h3></div>
    <?php if (empty($activity)): ?>
      <p class="empty-note">No activity yet — your recent job requests will show up here.</p>
    <?php endif; ?>
    <?php foreach ($activity as $b): ?>
      <div class="req-row">
        <div class="req-body">
          <div class="req-name"><?php echo htmlspecialchars($b['service_name']); ?> — <?php echo htmlspecialchars($b['customer_name']); ?></div>
          <div class="req-meta"><?php echo htmlspecialchars($b['schedule_date']); ?>, <?php echo htmlspecialchars($b['schedule_time']); ?> · Ref: <?php echo htmlspecialchars($b['booking_ref']); ?></div>
        </div>
        <div style="margin-left:auto;text-align:right;"><span class="tag"><?php echo htmlspecialchars($statusLabel[$b['status']] ?? $b['status']); ?></span></div>
      </div>
    <?php endforeach; ?>
  </div>

  <div class="stat-row" style="border:none;padding:0;margin:0 4px;">
    <div class="stat"><div class="num"><?php echo $totalJobs; ?></div><div class="lbl">total jobs</div></div>
    <div class="stat"><div class="num"><?php echo $completedJobs; ?></div><div class="lbl">completed</div></div>
  </div>
</div>

<div style="display:flex;gap:10px;margin-top:6px;flex-wrap:wrap;">
  <a href="logout.php" class="btn-secondary">Logout</a>
</div>

<script>
function showTab(name){
  document.querySelectorAll('.acct-tab').forEach(function(t){ t.classList.toggle('on', t.dataset.tab === name); });
  document.querySelectorAll('.acct-panel').forEach(function(p){ p.classList.toggle('hidden', p.id !== 'panel-' + name); });
  var url = new URL(window.location);
  url.searchParams.set('tab', name);
  url.searchParams.delete('msg'); url.searchParams.delete('err');
  window.history.replaceState({}, '', url);
}
document.querySelectorAll('.acct-tab').forEach(function(t){
  t.addEventListener('click', function(){ showTab(t.dataset.tab); });
});

function toggleEdit(formId){
  var form = document.getElementById(formId);
  form.classList.add('editing');
  form.querySelectorAll('input[name]:not([type=hidden])').forEach(function(i){
    if (i.type === 'checkbox') { i.disabled = false; } else { i.readOnly = false; }
  });
  form.querySelectorAll('select[name]').forEach(function(s){ s.disabled = false; });
  var first = form.querySelector('input[name]:not([type=hidden])');
  if (first) first.focus();
}
function cancelEdit(formId){
  var form = document.getElementById(formId);
  form.reset();
  form.classList.remove('editing');
  form.querySelectorAll('input[name]:not([type=hidden])').forEach(function(i){
    if (i.type === 'checkbox') { i.disabled = true; } else { i.readOnly = true; }
  });
  form.querySelectorAll('select[name]').forEach(function(s){ s.disabled = true; });
}

document.getElementById('avatarInput').addEventListener('change', function(e){
  var file = e.target.files[0];
  if (!file) return;
  var img = new Image();
  var reader = new FileReader();
  reader.onload = function(ev){
    img.onload = function(){
      var size = 320;
      var canvas = document.createElement('canvas');
      canvas.width = size; canvas.height = size;
      var ctx = canvas.getContext('2d');
      var s = Math.max(size / img.width, size / img.height);
      var w = img.width * s, h = img.height * s;
      ctx.drawImage(img, (size - w) / 2, (size - h) / 2, w, h);
      document.getElementById('avatarData').value = canvas.toDataURL('image/jpeg', 0.85);
      document.getElementById('photoForm').submit();
    };
    img.src = ev.target.result;
  };
  reader.readAsDataURL(file);
});
</script>

<?php require __DIR__ . '/../includes/footer.php'; ?>

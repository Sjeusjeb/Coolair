<?php
require __DIR__ . '/../config/session.php';
require __DIR__ . '/../config/supabase.php';
require __DIR__ . '/../config/security.php';

if (!isset($_SESSION['technician_id'])) {
    header('Location: login.php');
    exit;
}
csrf_verify();
$techId = $_SESSION['technician_id'];
$tab = in_array($_POST['tab'] ?? '', ['personal', 'account', 'activity'], true) ? $_POST['tab'] : 'personal';

$action = $_POST['action'] ?? '';

if ($action === 'update_profile') {
    $name       = trim($_POST['name'] ?? '');
    $specialty  = trim($_POST['specialty'] ?? '');
    $years      = (int)($_POST['years_experience'] ?? 0);
    $area       = trim($_POST['service_area'] ?? '');
    $fee        = (float)($_POST['starting_fee'] ?? 0);
    $avail      = $_POST['availability'] ?? 'available_now';
    $serviceIds = array_map('intval', $_POST['service_ids'] ?? []);

    if ($name === '') {
        header('Location: profile.php?err=' . urlencode('Full name is required.') . '&tab=personal');
        exit;
    }
    if (!in_array($avail, ['available_now', 'scheduled', 'offline'], true)) {
        $avail = 'available_now';
    }

    sb_update('technicians', ['id' => sb_eq($techId)], [
        'name' => $name, 'specialty' => $specialty, 'years_experience' => $years,
        'service_area' => $area, 'starting_fee' => $fee, 'availability' => $avail,
    ]);

    sb_delete('technician_services', ['technician_id' => sb_eq($techId)]);
    if ($serviceIds) {
        $rows = [];
        foreach ($serviceIds as $sid) { $rows[] = ['technician_id' => $techId, 'service_id' => $sid]; }
        sb_insert_many('technician_services', $rows);
    }

    $_SESSION['technician_name'] = $name;

    header('Location: profile.php?msg=' . urlencode('Profile updated.') . '&tab=personal');
    exit;
}

if ($action === 'change_password') {
    $current = $_POST['current_password'] ?? '';
    $new     = $_POST['new_password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    $tech = sb_get_one('technicians', ['id' => sb_eq($techId)]);

    if (!$tech || !password_verify($current, $tech['password'])) {
        header('Location: profile.php?err=' . urlencode('Current password is incorrect.') . '&tab=account');
        exit;
    }
    if (strlen($new) < 8) {
        header('Location: profile.php?err=' . urlencode('New password must be at least 8 characters.') . '&tab=account');
        exit;
    }
    if ($new !== $confirm) {
        header('Location: profile.php?err=' . urlencode('New password and confirmation do not match.') . '&tab=account');
        exit;
    }

    sb_update('technicians', ['id' => sb_eq($techId)], [
        'password' => password_hash($new, PASSWORD_DEFAULT),
    ]);

    header('Location: profile.php?msg=' . urlencode('Password updated.') . '&tab=account');
    exit;
}

if ($action === 'update_photo') {
    $data = $_POST['avatar_data'] ?? '';

    if ($data === '' || strpos($data, 'data:image/') !== 0) {
        header('Location: profile.php?err=' . urlencode('Please choose a valid image.') . '&tab=' . $tab);
        exit;
    }
    if (strlen($data) > 700000) {
        header('Location: profile.php?err=' . urlencode('Image is too large. Please try a smaller photo.') . '&tab=' . $tab);
        exit;
    }

    sb_update('technicians', ['id' => sb_eq($techId)], ['avatar_photo' => $data]);

    header('Location: profile.php?msg=' . urlencode('Profile photo updated.') . '&tab=' . $tab);
    exit;
}

header('Location: profile.php');
exit;

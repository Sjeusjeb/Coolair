<?php
require __DIR__ . '/../config/session.php';
require __DIR__ . '/../config/supabase.php';
require __DIR__ . '/../config/security.php';

$BASE = '../';

if (!isset($_SESSION['technician_id'])) {
    header('Location: login.php');
    exit;
}
$techId = $_SESSION['technician_id'];
$tech = sb_get_one('technicians', ['id' => sb_eq($techId)]);
if (!$tech) { header('Location: logout.php'); exit; }

$bookingId = (int)($_GET['id'] ?? 0);

$booking = sb_get_one('bookings', [
    'select'        => '*,services(name)',
    'id'            => sb_eq($bookingId),
    'technician_id' => sb_eq($techId),
]);

if (!$booking) {
    header('Location: dashboard.php');
    exit;
}
$booking['service_name'] = $booking['services']['name'] ?? '';

$pageTitle = 'Booking ' . $booking['booking_ref'];

$statusPill = [
    'pending' => ['Pending', 's-pending'], 'accepted' => ['Accepted', 's-accepted'],
    'on_the_way' => ['In Progress', 's-progress'], 'arrived' => ['In Progress', 's-progress'],
    'in_progress' => ['In Progress', 's-progress'], 'completed' => ['Completed', 's-completed'],
    'declined' => ['Declined', 's-declined'], 'cancelled' => ['Cancelled', 's-cancelled'],
];
[$sLabel, $sClass] = $statusPill[$booking['status']] ?? [ucfirst($booking['status']), 's-pending'];

$nextAction = [
    'pending'     => ['accept',      'Accept booking'],
    'accepted'    => ['on_the_way',  'Mark on the way'],
    'on_the_way'  => ['arrived',     'Mark arrived'],
    'arrived'     => ['in_progress', 'Start service'],
    'in_progress' => ['completed',   'Mark completed'],
];

$panelRole      = 'technician';
$panelActive    = 'dashboard';
$panelUserName  = $tech['name'];
$panelUserSub   = 'Technician';
$panelUserPhoto = $tech['avatar_photo'] ?? '';

require __DIR__ . '/../includes/panel_header.php';
?>

<a href="dashboard.php#tasks" style="font-size:12.5px;font-weight:700;color:var(--blue-900);display:inline-block;margin-bottom:16px;">&larr; Back to my tasks</a>

<?php if (!empty($_GET['msg'])): ?><div class="success-box"><?php echo htmlspecialchars($_GET['msg']); ?></div><?php endif; ?>

<div class="panel-grid">
  <div>
    <div class="side-card">
      <div class="side-card-head">
        <h3><?php echo panel_icon('tasks'); ?> <?php echo htmlspecialchars($booking['booking_ref']); ?></h3>
        <span class="pill-tag <?php echo $sClass; ?>"><?php echo $sLabel; ?></span>
      </div>

      <div class="info-row"><span class="k"><?php echo panel_icon('wrench'); ?></span><span class="v" style="text-align:left;flex:1;">Service<br><b style="font-weight:700;"><?php echo htmlspecialchars($booking['service_name']); ?></b></span></div>
      <div class="info-row"><span class="k"><?php echo panel_icon('user'); ?></span><span class="v" style="text-align:left;flex:1;">Customer<br><b style="font-weight:700;"><?php echo htmlspecialchars($booking['customer_name']); ?></b></span></div>
      <div class="info-row"><span class="k"><?php echo panel_icon('phone'); ?></span><span class="v" style="text-align:left;flex:1;">Phone<br><b style="font-weight:700;"><?php echo htmlspecialchars($booking['customer_phone'] ?: '—'); ?></b></span></div>
      <div class="info-row"><span class="k"><?php echo panel_icon('pin'); ?></span><span class="v" style="text-align:left;flex:1;">Address<br><b style="font-weight:700;"><?php echo htmlspecialchars($booking['address']); ?></b></span></div>
      <div class="info-row"><span class="k"><?php echo panel_icon('calendar'); ?></span><span class="v" style="text-align:left;flex:1;">Schedule<br><b style="font-weight:700;"><?php echo htmlspecialchars(date('M j, Y', strtotime($booking['schedule_date']))); ?>, <?php echo htmlspecialchars($booking['schedule_time']); ?></b></span></div>

      <div style="margin-top:18px;">
        <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:0.03em;color:var(--ink-600);margin-bottom:8px;">Customer's reported problem</div>
        <div style="background:var(--bg,#F5F7F9);border:1px solid var(--line);border-radius:var(--r-md);padding:14px 16px;font-size:13.5px;line-height:1.6;color:var(--ink-900,#1c2b33);">
          <?php echo !empty($booking['problem_description']) ? nl2br(htmlspecialchars($booking['problem_description'])) : '<span style="color:var(--ink-600);">No description provided by the customer.</span>'; ?>
        </div>
      </div>

      <?php if ($booking['estimated_min'] || $booking['estimated_max']): ?>
      <div class="info-row" style="margin-top:14px;"><span class="k"><?php echo panel_icon('wallet'); ?></span><span class="v" style="text-align:left;flex:1;">Estimated price<br><b style="font-weight:700;">₱<?php echo number_format($booking['estimated_min'], 0); ?> – ₱<?php echo number_format($booking['estimated_max'], 0); ?></b></span></div>
      <?php endif; ?>
      <?php if ($booking['final_price']): ?>
      <div class="info-row"><span class="k"><?php echo panel_icon('wallet'); ?></span><span class="v" style="text-align:left;flex:1;">Final price<br><b style="font-weight:700;">₱<?php echo number_format($booking['final_price'], 0); ?></b></span></div>
      <?php endif; ?>

      <?php if (isset($nextAction[$booking['status']])): [$actKey, $actLabel] = $nextAction[$booking['status']]; ?>
        <form method="post" action="actions.php" style="margin-top:18px;">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="booking_id" value="<?php echo $booking['id']; ?>">
          <input type="hidden" name="action" value="<?php echo $actKey; ?>">
          <button type="submit" class="table-btn" style="padding:10px 20px;font-size:13px;"><?php echo $actLabel; ?></button>
        </form>
      <?php endif; ?>

      <form method="post" action="actions.php" style="margin-top:10px;" onsubmit="return confirm('Delete this task? This cannot be undone.');">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="booking_id" value="<?php echo $booking['id']; ?>">
        <input type="hidden" name="action" value="delete">
        <button type="submit" class="table-btn" style="background:var(--red-500);padding:10px 20px;font-size:13px;">Delete task</button>
      </form>
    </div>
  </div>
</div>

<?php require __DIR__ . '/../includes/panel_footer.php'; ?>

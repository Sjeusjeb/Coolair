<?php
require __DIR__ . '/../config/session.php';
require __DIR__ . '/../config/supabase.php';
require __DIR__ . '/../config/security.php';

if (!isset($_SESSION['technician_id'])) {
    header('Location: login.php');
    exit;
}
csrf_verify();
$techId = $_SESSION['technician_id'];

$bookingId = (int)($_POST['booking_id'] ?? 0);
$action = $_POST['action'] ?? '';

$validActions = [
    'accept'      => 'accepted',
    'decline'     => 'declined',
    'on_the_way'  => 'on_the_way',
    'arrived'     => 'arrived',
    'in_progress' => 'in_progress',
    'completed'   => 'completed',
    'cancel'      => 'cancelled',
];

// Deleting a task removes it from this technician's list entirely.
if ($action === 'delete') {
    $owned = sb_get_one('bookings', [
        'id'            => sb_eq($bookingId),
        'technician_id' => sb_eq($techId),
        'select'        => 'id',
    ]);

    if ($owned) {
        sb_delete('bookings', ['id' => sb_eq($bookingId)]);
        header('Location: dashboard.php?msg=' . urlencode('Task deleted.'));
        exit;
    }

    header('Location: dashboard.php');
    exit;
}

if (!isset($validActions[$action])) {
    header('Location: dashboard.php');
    exit;
}
$newStatus = $validActions[$action];

// Make sure this booking actually belongs to the logged-in technician,
// and that it isn't already in a final state
$check = sb_get_one('bookings', [
    'id'             => sb_eq($bookingId),
    'technician_id'  => sb_eq($techId),
    'status'         => 'not.in.(completed,declined,cancelled)',
    'select'         => 'id',
]);

if ($check) {
    sb_update('bookings', ['id' => sb_eq($bookingId)], ['status' => $newStatus]);
    sb_insert('booking_status_log', ['booking_id' => $bookingId, 'status' => $newStatus]);

    $messages = [
        'accepted'    => 'Booking accepted.',
        'declined'    => 'Booking declined.',
        'on_the_way'  => 'Marked as on the way.',
        'arrived'     => 'Marked as arrived.',
        'in_progress' => 'Service marked in progress.',
        'completed'   => 'Job marked completed.',
        'cancelled'   => 'Booking cancelled.',
    ];
    header('Location: dashboard.php?msg=' . urlencode($messages[$newStatus]));
    exit;
}

header('Location: dashboard.php');
exit;

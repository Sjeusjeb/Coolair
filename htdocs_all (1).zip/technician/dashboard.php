<?php
require __DIR__ . '/../config/session.php';
require __DIR__ . '/../config/supabase.php';
require __DIR__ . '/../config/security.php';

$BASE = '../';
$pageTitle = 'Technician Dashboard';

if (!isset($_SESSION['technician_id'])) {
    header('Location: login.php');
    exit;
}
$techId = $_SESSION['technician_id'];
$tech = sb_get_one('technicians', ['id' => sb_eq($techId)]);
if (!$tech) { header('Location: logout.php'); exit; }

$monthStart = date('Y-m-01');

// Incoming (pending) requests
$pending = sb_get('bookings', [
    'select' => '*,services(name)', 'technician_id' => sb_eq($techId),
    'status' => sb_eq('pending'), 'order' => 'created_at.asc',
]);
foreach ($pending as &$b) { $b['service_name'] = $b['services']['name'] ?? ''; }
unset($b);

// Active / scheduled jobs (already accepted, not yet completed)
$active = sb_get('bookings', [
    'select' => '*,services(name)', 'technician_id' => sb_eq($techId),
    'status' => 'in.(accepted,on_the_way,arrived,in_progress)',
    'order'  => 'schedule_date.asc,schedule_time.asc',
]);
foreach ($active as &$b) { $b['service_name'] = $b['services']['name'] ?? ''; }
unset($b);

$assignedCount     = count($pending) + count($active);
$completedThisMonth = sb_count('bookings', [
    'technician_id' => sb_eq($techId), 'status' => sb_eq('completed'), 'updated_at' => 'gte.' . $monthStart,
]);
$totalThisMonth = sb_count('bookings', ['technician_id' => sb_eq($techId), 'created_at' => 'gte.' . $monthStart]);

$nextAction = [
    'accepted'    => ['on_the_way',  'Mark on the way'],
    'on_the_way'  => ['arrived',     'Mark arrived'],
    'arrived'     => ['in_progress', 'Start service'],
    'in_progress' => ['completed',   'Mark completed'],
];
$priorityFor = function (array $b): array {
    if (in_array($b['status'], ['in_progress', 'on_the_way', 'arrived'], true)) return ['High', 'p-high'];
    $days = (strtotime($b['schedule_date']) - strtotime(date('Y-m-d'))) / 86400;
    if ($days <= 0) return ['High', 'p-high'];
    if ($days <= 2) return ['Medium', 'p-medium'];
    return ['Low', 'p-low'];
};
$statusPill = [
    'pending' => ['Pending', 's-pending'], 'accepted' => ['Accepted', 's-accepted'],
    'on_the_way' => ['In Progress', 's-progress'], 'arrived' => ['In Progress', 's-progress'],
    'in_progress' => ['In Progress', 's-progress'], 'completed' => ['Completed', 's-completed'],
];
$tasks = array_slice(array_merge($pending, $active), 0, 8);

// Recent activity feed, built from this technician's most recent status changes
$statusLog = sb_get('booking_status_log', [
    'select' => 'status,changed_at,bookings!inner(booking_ref,technician_id,services(name),customer_name)',
    'bookings.technician_id' => sb_eq($techId),
    'order'  => 'changed_at.desc', 'limit' => 6,
]);

$panelRole      = 'technician';
$panelActive    = 'dashboard';
$panelUserName  = $tech['name'];
$panelUserSub   = 'Technician';
$panelUserPhoto = $tech['avatar_photo'] ?? '';

require __DIR__ . '/../includes/panel_header.php';
?>

<?php if (!empty($_GET['msg'])): ?><div class="success-box"><?php echo htmlspecialchars($_GET['msg']); ?></div><?php endif; ?>

<div class="panel-welcome">
  <div class="mini-avatar" style="width:78px;height:78px;font-size:24px;background:<?php echo htmlspecialchars($tech['avatar_color']); ?>;border:3px solid rgba(255,255,255,0.85);">
    <?php if (!empty($tech['avatar_photo'])): ?><img src="<?php echo htmlspecialchars($tech['avatar_photo']); ?>" alt=""><?php else: echo htmlspecialchars($tech['avatar_initials']); endif; ?>
  </div>
  <div>
    <div class="panel-welcome-title">Welcome back, <?php echo htmlspecialchars(explode(' ', $tech['name'])[0]); ?>!</div>
    <div class="panel-welcome-sub">Here's your current tasks and system updates.</div>
    <span class="verified-tag" style="background:var(--green-100);color:var(--green-600);margin-top:9px;display:inline-flex;">Active</span>
  </div>
  <div class="panel-welcome-date"><?php echo panel_icon('calendar'); ?> <?php echo date('F j, Y \· l, g:i A'); ?></div>
</div>

<div class="stat-card-grid">
  <div class="stat-card">
    <div class="stat-card-icon" style="background:var(--blue-900);"><?php echo panel_icon('tasks'); ?></div>
    <div class="stat-card-lbl">Assigned Tasks</div>
    <div class="stat-card-num"><?php echo $assignedCount; ?></div>
    <div class="stat-card-sub"><?php echo count($pending); ?> pending, <?php echo count($active); ?> in progress</div>
  </div>
  <div class="stat-card">
    <div class="stat-card-icon" style="background:var(--green-600);"><?php echo panel_icon('check-circle'); ?></div>
    <div class="stat-card-lbl">Completed Tasks</div>
    <div class="stat-card-num"><?php echo $completedThisMonth; ?></div>
    <div class="stat-card-sub">this month</div>
  </div>
  <div class="stat-card">
    <div class="stat-card-icon" style="background:var(--amber-500);"><?php echo panel_icon('clock'); ?></div>
    <div class="stat-card-lbl">On Going</div>
    <div class="stat-card-num"><?php echo count($active); ?></div>
    <div class="stat-card-sub">in progress</div>
  </div>
  <div class="stat-card">
    <div class="stat-card-icon" style="background:var(--violet-500);"><?php echo panel_icon('calendar'); ?></div>
    <div class="stat-card-lbl">Total Tasks</div>
    <div class="stat-card-num"><?php echo $totalThisMonth; ?></div>
    <div class="stat-card-sub">this month</div>
  </div>
</div>

<div class="panel-grid">
  <div>
    <div class="side-card" id="tasks">
      <div class="side-card-head">
        <h3><?php echo panel_icon('tasks'); ?> My Assigned Tasks</h3>
        <a href="#tasks" style="font-size:12.5px;font-weight:700;color:var(--blue-900);">View All</a>
      </div>
      <?php if (empty($tasks)): ?>
        <p class="empty-note">No assigned tasks right now.</p>
      <?php else: ?>
      <div style="overflow-x:auto;">
        <table class="data-table">
          <thead><tr><th>Ref</th><th>Task</th><th>Priority</th><th>Status</th><th>Date</th><th>Actions</th></tr></thead>
          <tbody>
          <?php foreach ($tasks as $b): [$pLabel, $pClass] = $priorityFor($b); $sLabel = $statusPill[$b['status']][0] ?? ucfirst($b['status']); $sClass = $statusPill[$b['status']][1] ?? 's-pending'; ?>
            <tr>
              <td style="font-weight:700;"><?php echo htmlspecialchars($b['booking_ref']); ?></td>
              <td>
                <?php echo htmlspecialchars($b['service_name']); ?> (<?php echo htmlspecialchars($b['customer_name']); ?>)
                <?php if (!empty($b['problem_description'])): $prob = trim($b['problem_description']); $probShort = mb_strlen($prob) > 60 ? mb_substr($prob, 0, 60) . '…' : $prob; ?>
                  <div style="font-size:11.5px;font-weight:500;color:var(--ink-600);margin-top:3px;max-width:260px;" title="<?php echo htmlspecialchars($prob); ?>">
                    <?php echo htmlspecialchars($probShort); ?>
                  </div>
                <?php endif; ?>
              </td>
              <td><span class="pill-tag <?php echo $pClass; ?>"><?php echo $pLabel; ?></span></td>
              <td><span class="pill-tag <?php echo $sClass; ?>"><?php echo $sLabel; ?></span></td>
              <td><?php echo date('M j, Y', strtotime($b['created_at'])); ?></td>
              <td style="white-space:nowrap;">
                <a href="booking.php?id=<?php echo $b['id']; ?>" class="table-icon-btn edit" title="View booking details"><?php echo panel_icon('eye'); ?></a>
                <?php if ($b['status'] === 'pending'): ?>
                  <form method="post" action="actions.php" style="display:inline;">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="booking_id" value="<?php echo $b['id']; ?>">
                    <input type="hidden" name="action" value="accept">
                    <button type="submit" class="table-btn">Accept</button>
                  </form>
                <?php elseif (isset($nextAction[$b['status']])): ?>
                  <form method="post" action="actions.php" style="display:inline;">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="booking_id" value="<?php echo $b['id']; ?>">
                    <input type="hidden" name="action" value="<?php echo $nextAction[$b['status']][0]; ?>">
                    <button type="submit" class="table-btn"><?php echo $nextAction[$b['status']][1]; ?></button>
                  </form>
                <?php endif; ?>
                <form method="post" action="actions.php" style="display:inline;" onsubmit="return confirm('Delete this task? This cannot be undone.');">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="booking_id" value="<?php echo $b['id']; ?>">
                  <input type="hidden" name="action" value="delete">
                  <button type="submit" class="table-btn" style="background:var(--red-500);margin-left:6px;">Delete</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?php endif; ?>
    </div>

    <div class="side-card">
      <div class="side-card-head">
        <h3><?php echo panel_icon('clock'); ?> Recent Activity</h3>
        <a href="#tasks" style="font-size:12.5px;font-weight:700;color:var(--blue-900);">View All</a>
      </div>
      <?php if (empty($statusLog)): ?>
        <p class="empty-note">No recent activity yet.</p>
      <?php endif; ?>
      <?php foreach ($statusLog as $l):
        $ref = $l['bookings']['booking_ref'] ?? '';
        $svc = $l['bookings']['services']['name'] ?? '';
        $cust = $l['bookings']['customer_name'] ?? '';
        $titles = [
          'accepted' => 'Task assigned', 'completed' => 'Task completed', 'pending' => 'Task assigned',
        ];
        $title = $titles[$l['status']] ?? 'Task updated';
        $icon  = $l['status'] === 'completed' ? 'check-circle' : ($l['status'] === 'accepted' ? 'calendar' : 'clock');
        $color = $l['status'] === 'completed' ? 'var(--green-600)' : 'var(--sky-500)';
      ?>
        <div class="activity-item">
          <div class="activity-dot" style="background:<?php echo $color; ?>;"><?php echo panel_icon($icon); ?></div>
          <div class="activity-body">
            <div class="activity-title"><?php echo $title; ?></div>
            <div class="activity-sub">"<?php echo htmlspecialchars($svc); ?>" for <?php echo htmlspecialchars($cust); ?> (<?php echo htmlspecialchars($ref); ?>)</div>
          </div>
          <div class="activity-time"><?php echo date('M j · g:i A', strtotime($l['changed_at'])); ?></div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>

  <div>
    <div class="side-card">
      <div class="side-card-head">
        <h3><?php echo panel_icon('user'); ?> Profile Information</h3>
        <a href="profile.php" style="color:var(--ink-600);"><?php echo panel_icon('pencil'); ?></a>
      </div>
      <div class="mini-avatar-wrap">
        <div class="mini-avatar" style="background:<?php echo htmlspecialchars($tech['avatar_color']); ?>;">
          <?php if (!empty($tech['avatar_photo'])): ?><img src="<?php echo htmlspecialchars($tech['avatar_photo']); ?>" alt=""><?php else: echo htmlspecialchars($tech['avatar_initials']); endif; ?>
        </div>
        <div style="font-weight:800;font-size:15px;margin-top:10px;"><?php echo htmlspecialchars($tech['name']); ?></div>
        <div style="font-size:12px;color:var(--ink-600);"><?php echo htmlspecialchars($tech['specialty'] ?: 'Technician'); ?></div>
        <span class="verified-tag" style="background:var(--green-100);color:var(--green-600);margin-top:7px;">Active</span>
      </div>
      <div class="info-row"><span class="k"><?php echo panel_icon('shield'); ?></span><span class="v" style="text-align:left;flex:1;">Technician ID<br><b style="font-weight:700;">TECH-<?php echo str_pad($tech['id'], 3, '0', STR_PAD_LEFT); ?></b></span></div>
      <div class="info-row"><span class="k"><?php echo panel_icon('mail'); ?></span><span class="v" style="text-align:left;flex:1;">Email<br><b style="font-weight:700;"><?php echo htmlspecialchars($tech['email']); ?></b></span></div>
      <div class="info-row"><span class="k"><?php echo panel_icon('phone'); ?></span><span class="v" style="text-align:left;flex:1;">Service area<br><b style="font-weight:700;"><?php echo htmlspecialchars($tech['service_area'] ?: '—'); ?></b></span></div>
      <div class="info-row"><span class="k"><?php echo panel_icon('calendar'); ?></span><span class="v" style="text-align:left;flex:1;">Joined<br><b style="font-weight:700;"><?php echo date('F j, Y', strtotime($tech['created_at'])); ?></b></span></div>
    </div>

    <div class="side-card">
      <div class="side-card-head"><h3><?php echo panel_icon('gear'); ?> Quick Actions</h3></div>
      <a href="#tasks" class="quick-action-btn primary"><?php echo panel_icon('tasks'); ?> View My Tasks</a>
      <a href="profile.php" class="quick-action-btn"><?php echo panel_icon('calendar'); ?> Update Availability</a>
      <a href="profile.php" class="quick-action-btn"><?php echo panel_icon('user'); ?> Edit Profile</a>
      <a href="profile.php?tab=account" class="quick-action-btn"><?php echo panel_icon('shield'); ?> Change Password</a>
    </div>

    <div class="side-card" style="padding:0;border:none;box-shadow:none;background:none;">
      <div class="help-box">
        <div class="t"><?php echo panel_icon('shield'); ?> Need Help?</div>
        <p>Contact your admin for any system issues or concerns.</p>
      </div>
    </div>
  </div>
</div>

<?php require __DIR__ . '/../includes/panel_footer.php'; ?>

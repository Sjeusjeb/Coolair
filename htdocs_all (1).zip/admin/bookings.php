<?php
require __DIR__ . '/../config/session.php';
require __DIR__ . '/../config/supabase.php';
require __DIR__ . '/../config/security.php';

$BASE = '../';
$pageTitle = 'All Bookings';

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

$statusFilter = $_GET['status'] ?? '';
$statusLabel = [
    'pending'     => 'Pending',
    'accepted'    => 'Accepted',
    'declined'    => 'Declined',
    'on_the_way'  => 'On the way',
    'arrived'     => 'Arrived',
    'in_progress' => 'In progress',
    'completed'   => 'Completed',
    'cancelled'   => 'Cancelled',
];

$params = [
    'select' => '*,customers(name,phone),technicians(name),services(name)',
    'order'  => 'created_at.desc',
];
if ($statusFilter && isset($statusLabel[$statusFilter])) {
    $params['status'] = sb_eq($statusFilter);
}
$bookings = sb_get('bookings', $params);
foreach ($bookings as &$b) {
    $b['cust_name']  = $b['customers']['name'] ?? '';
    $b['cust_phone'] = $b['customers']['phone'] ?? '';
    $b['tech_name']  = $b['technicians']['name'] ?? '';
    $b['service_name'] = $b['services']['name'] ?? '';
}
unset($b);

require __DIR__ . '/../includes/header.php';
?>

<a href="dashboard.php" class="btn-secondary" style="display:inline-block;margin-bottom:18px;">&larr; Dashboard</a>
<h2 style="margin-bottom:14px;">All bookings</h2>

<?php if (isset($_GET['msg'])): ?>
  <div class="success-box"><?php echo htmlspecialchars($_GET['msg']); ?></div>
<?php endif; ?>

<div class="chip-row">
  <a class="chip <?php echo $statusFilter === '' ? 'on' : ''; ?>" href="bookings.php">All</a>
  <?php foreach ($statusLabel as $key => $label): ?>
    <a class="chip <?php echo $statusFilter === $key ? 'on' : ''; ?>" href="bookings.php?status=<?php echo $key; ?>"><?php echo $label; ?></a>
  <?php endforeach; ?>
</div>

<div class="card">
  <?php if (empty($bookings)): ?>
    <p class="empty-note">No bookings found.</p>
  <?php endif; ?>
  <?php foreach ($bookings as $b): ?>
    <div class="req-row">
      <div class="req-body">
        <div class="req-name"><?php echo htmlspecialchars($b['cust_name']); ?> → <?php echo htmlspecialchars($b['tech_name']); ?> · <?php echo htmlspecialchars($b['service_name']); ?></div>
        <div class="req-meta">Ref: <?php echo htmlspecialchars($b['booking_ref']); ?> · <?php echo htmlspecialchars($b['schedule_date']); ?>, <?php echo htmlspecialchars($b['schedule_time']); ?></div>
        <div class="req-meta"><?php echo htmlspecialchars($b['address']); ?></div>
      </div>
      <span class="tag"><?php echo htmlspecialchars($statusLabel[$b['status']] ?? $b['status']); ?></span>
      <?php if (!in_array($b['status'], ['completed', 'cancelled', 'declined'], true)): ?>
        <form method="post" action="booking_actions.php" onsubmit="return confirm('Cancel this booking?');" style="margin-left:10px;">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="booking_id" value="<?php echo $b['id']; ?>">
          <input type="hidden" name="action" value="cancel">
          <button type="submit" class="btn-mini decline">Cancel</button>
        </form>
      <?php endif; ?>
    </div>
  <?php endforeach; ?>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>

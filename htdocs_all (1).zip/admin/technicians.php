<?php
require __DIR__ . '/../config/session.php';
require __DIR__ . '/../config/supabase.php';
require __DIR__ . '/../config/security.php';

$BASE = '../';
$pageTitle = 'Manage Technicians';

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

$technicians = sb_get('technicians', ['order' => 'created_at.desc']);
$services = sb_get('services', ['order' => 'name.asc']);

// Map technician_id => [service_id, ...] so we can pre-check each technician's
// current services in the "Edit services" panel below.
$allLinks = sb_get('technician_services', ['select' => 'technician_id,service_id']);
$techServiceMap = [];
foreach ($allLinks as $link) {
    $techServiceMap[$link['technician_id']][] = (int)$link['service_id'];
}

require __DIR__ . '/../includes/header.php';
?>

<a href="dashboard.php" class="btn-secondary" style="display:inline-block;margin-bottom:18px;">&larr; Dashboard</a>
<h2 style="margin-bottom:18px;">Manage technicians</h2>

<?php if (isset($_GET['msg'])): ?>
  <div class="success-box"><?php echo htmlspecialchars($_GET['msg']); ?></div>
<?php endif; ?>
<?php if (isset($_GET['err'])): ?>
  <div class="error-box"><?php echo htmlspecialchars($_GET['err']); ?></div>
<?php endif; ?>

<div class="dash-grid">
  <div>
    <div class="card">
      <h3>All technicians (<?php echo count($technicians); ?>)</h3>
      <?php foreach ($technicians as $t): ?>
        <div class="req-row">
          <div class="avatar" style="background:<?php echo htmlspecialchars($t['avatar_color']); ?>"><?php echo htmlspecialchars($t['avatar_initials']); ?></div>
          <div class="req-body">
            <div class="req-name"><?php echo htmlspecialchars($t['name']); ?></div>
            <div class="req-meta"><?php echo htmlspecialchars($t['specialty']); ?> · ★ <?php echo number_format($t['rating'],1); ?> · ₱<?php echo number_format($t['starting_fee']); ?></div>
            <div class="badge-row">
              <?php if ($t['is_verified']): ?><span class="verified-tag">Verified</span><?php endif; ?>
              <?php if ($t['background_checked']): ?><span class="verified-tag" style="background:var(--amber-100);color:#8A5A05;">BG checked</span><?php endif; ?>
            </div>
          </div>
          <div class="req-actions" style="flex-direction:column;align-items:stretch;">
            <button type="button" class="btn-mini next" style="background:var(--violet-500);" onclick="toggleServicesPanel(<?php echo $t['id']; ?>)">Edit services</button>
            <form method="post" action="technician_actions.php">
              <?php echo csrf_field(); ?>
              <input type="hidden" name="technician_id" value="<?php echo $t['id']; ?>">
              <input type="hidden" name="action" value="toggle_verified">
              <button type="submit" class="btn-mini next"><?php echo $t['is_verified'] ? 'Unverify' : 'Verify'; ?></button>
            </form>
            <form method="post" action="technician_actions.php" onsubmit="return confirm('Delete this technician? This cannot be undone.');">
              <?php echo csrf_field(); ?>
              <input type="hidden" name="technician_id" value="<?php echo $t['id']; ?>">
              <input type="hidden" name="action" value="delete">
              <button type="submit" class="btn-mini decline">Delete</button>
            </form>
          </div>
        </div>

        <div class="card" id="services-panel-<?php echo $t['id']; ?>" style="display:none;background:var(--bg);margin:-6px 0 14px;padding:16px;">
          <form method="post" action="technician_actions.php">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="technician_id" value="<?php echo $t['id']; ?>">
            <input type="hidden" name="action" value="edit_services">
            <label class="field-label" style="margin-top:0;">Services offered by <?php echo htmlspecialchars($t['name']); ?></label>
            <div class="service-pick">
              <?php $currentIds = $techServiceMap[$t['id']] ?? []; ?>
              <?php foreach ($services as $s): ?>
                <label class="service-opt <?php echo in_array((int)$s['id'], $currentIds, true) ? 'on' : ''; ?>">
                  <input type="checkbox" name="service_ids[]" value="<?php echo $s['id']; ?>"
                         style="display:inline;"
                         <?php echo in_array((int)$s['id'], $currentIds, true) ? 'checked' : ''; ?>>
                  <?php echo htmlspecialchars($s['name']); ?>
                </label>
              <?php endforeach; ?>
            </div>
            <div style="display:flex;gap:8px;margin-top:14px;">
              <button type="submit" class="btn-primary">Save services</button>
              <button type="button" class="btn-secondary" onclick="toggleServicesPanel(<?php echo $t['id']; ?>)">Cancel</button>
            </div>
          </form>
        </div>
      <?php endforeach; ?>
    </div>
  </div>

  <div>
    <div class="card">
      <h3>Add a technician</h3>
      <form method="post" action="technician_actions.php">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="action" value="add">

        <label class="field-label" style="margin-top:0;">Full name</label>
        <input class="field-input" name="name" required>

        <label class="field-label">Email (login)</label>
        <input class="field-input" type="email" name="email" required>

        <label class="field-label">Password</label>
        <input class="field-input" type="password" name="password" required>

        <label class="field-label">Specialty</label>
        <input class="field-input" name="specialty" placeholder="e.g. Aircon Specialist">

        <label class="field-label">Years of experience</label>
        <input class="field-input" type="number" min="0" name="years_experience" value="1">

        <label class="field-label">Service area</label>
        <input class="field-input" name="service_area" placeholder="e.g. Biñan, Laguna">

        <label class="field-label">Starting fee (₱)</label>
        <input class="field-input" type="number" min="0" step="1" name="starting_fee" value="350">

        <label class="field-label">Avatar initials</label>
        <input class="field-input" name="avatar_initials" maxlength="4" placeholder="e.g. JD">

        <label class="field-label">Services offered</label>
        <div class="service-pick">
          <?php foreach ($services as $s): ?>
            <label class="service-opt">
              <input type="checkbox" name="service_ids[]" value="<?php echo $s['id']; ?>" style="display:inline;">
              <?php echo htmlspecialchars($s['name']); ?>
            </label>
          <?php endforeach; ?>
        </div>

        <button type="submit" class="btn-primary btn-block" style="margin-top:16px;">Add technician</button>
      </form>
    </div>
  </div>
</div>

<script>
function toggleServicesPanel(id){
  var panel = document.getElementById('services-panel-' + id);
  if (!panel) return;
  panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
}
// Click a service pill to toggle its checked look immediately (the checkbox itself still submits normally)
document.querySelectorAll('.service-opt').forEach(function(label){
  var box = label.querySelector('input[type=checkbox]');
  if (!box) return;
  box.addEventListener('change', function(){ label.classList.toggle('on', box.checked); });
});
</script>

<?php require __DIR__ . '/../includes/footer.php'; ?>

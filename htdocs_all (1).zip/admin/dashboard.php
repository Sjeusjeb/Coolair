<?php
require __DIR__ . '/../config/session.php';
require __DIR__ . '/../config/supabase.php';
require __DIR__ . '/../config/security.php';

$BASE = '../';
$pageTitle = 'Admin Dashboard';

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

$stats = sb_rpc('admin_dashboard_stats');
$stats = $stats[0] ?? ['total_technicians' => 0, 'total_customers' => 0, 'total_bookings' => 0, 'revenue_this_week' => 0];
$totalTechnicians = $stats['total_technicians'];
$totalCustomers   = $stats['total_customers'];
$totalBookings    = $stats['total_bookings'];
$revenueThisWeek  = $stats['revenue_this_week'];

$activeTechCount   = sb_count('technicians', ['availability' => 'neq.offline']);
$inactiveTechCount = sb_count('technicians', ['availability' => sb_eq('offline')]);
$activePct   = $totalTechnicians > 0 ? round($activeTechCount / $totalTechnicians * 100) : 0;
$inactivePct = $totalTechnicians > 0 ? round($inactiveTechCount / $totalTechnicians * 100) : 0;
$donutDeg = $totalTechnicians > 0 ? round($activeTechCount / $totalTechnicians * 360) : 0;

$technicians = sb_get('technicians', ['order' => 'created_at.desc', 'limit' => 10]);
$services = sb_get('services', ['order' => 'name.asc']);

$panelRole      = 'admin';
$panelActive    = 'dashboard';
$panelUserName  = $_SESSION['admin_name'];
$panelUserSub   = 'Administrator';
$panelUserPhoto = '';

require __DIR__ . '/../includes/panel_header.php';
?>

<?php if (isset($_GET['msg'])): ?><div class="success-box"><?php echo htmlspecialchars($_GET['msg']); ?></div><?php endif; ?>
<?php if (isset($_GET['err'])): ?><div class="error-box"><?php echo htmlspecialchars($_GET['err']); ?></div><?php endif; ?>

<div class="panel-welcome">
  <div class="mini-avatar" style="width:70px;height:70px;font-size:22px;background:var(--blue-700);border:3px solid rgba(255,255,255,0.85);">
    <?php echo htmlspecialchars(strtoupper(substr($_SESSION['admin_name'], 0, 1))); ?>
  </div>
  <div>
    <div class="panel-welcome-title">Welcome, <?php echo htmlspecialchars($_SESSION['admin_name']); ?>!</div>
    <div class="panel-welcome-sub">Here's what's happening with your system today.</div>
  </div>
  <div class="panel-welcome-date"><?php echo panel_icon('calendar'); ?> <?php echo date('F j, Y \· l, g:i A'); ?></div>
</div>

<div class="stat-card-grid">
  <div class="stat-card">
    <div class="stat-card-icon" style="background:var(--blue-900);"><?php echo panel_icon('users'); ?></div>
    <div class="stat-card-lbl">Total Technicians</div>
    <div class="stat-card-num"><?php echo $totalTechnicians; ?></div>
    <div class="stat-card-sub"><?php echo $totalCustomers; ?> customers total</div>
  </div>
  <div class="stat-card">
    <div class="stat-card-icon" style="background:var(--green-600);"><?php echo panel_icon('check-circle'); ?></div>
    <div class="stat-card-lbl">Active Technicians</div>
    <div class="stat-card-num"><?php echo $activeTechCount; ?></div>
    <div class="stat-card-sub"><?php echo $activePct; ?>% of total</div>
  </div>
  <div class="stat-card">
    <div class="stat-card-icon" style="background:var(--amber-500);"><?php echo panel_icon('clock'); ?></div>
    <div class="stat-card-lbl">Inactive Technicians</div>
    <div class="stat-card-num"><?php echo $inactiveTechCount; ?></div>
    <div class="stat-card-sub"><?php echo $inactivePct; ?>% of total</div>
  </div>
  <div class="stat-card">
    <div class="stat-card-icon" style="background:var(--violet-500);"><?php echo panel_icon('wallet'); ?></div>
    <div class="stat-card-lbl">Total Bookings</div>
    <div class="stat-card-num"><?php echo $totalBookings; ?></div>
    <div class="stat-card-sub">₱<?php echo number_format($revenueThisWeek); ?> this week</div>
  </div>
</div>

<div class="panel-grid">
  <div>
    <div class="side-card">
      <div class="side-card-head">
        <h3><?php echo panel_icon('users'); ?> Technicians</h3>
        <a href="technicians.php" class="btn-secondary" style="padding:8px 16px;font-size:12.5px;"><?php echo panel_icon('plus'); ?> Manage</a>
      </div>
      <p style="font-size:12.5px;color:var(--ink-600);margin:-8px 0 14px;">Manage and monitor all system technicians.</p>
      <?php if (empty($technicians)): ?>
        <p class="empty-note">No technicians yet.</p>
      <?php else: ?>
      <div style="overflow-x:auto;">
        <table class="data-table">
          <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Specialty</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>
          <?php foreach ($technicians as $t): $isActive = $t['availability'] !== 'offline'; ?>
            <tr>
              <td style="font-weight:700;">TECH-<?php echo str_pad($t['id'], 3, '0', STR_PAD_LEFT); ?></td>
              <td><?php echo htmlspecialchars($t['name']); ?></td>
              <td style="color:var(--ink-600);"><?php echo htmlspecialchars($t['email']); ?></td>
              <td style="color:var(--ink-600);"><?php echo htmlspecialchars($t['specialty'] ?: '—'); ?></td>
              <td><span class="pill-tag <?php echo $isActive ? 's-active' : 's-inactive'; ?>">● <?php echo $isActive ? 'Active' : 'Inactive'; ?></span></td>
              <td>
                <a href="technicians.php" class="table-icon-btn edit" title="Manage"><?php echo panel_icon('pencil'); ?></a>
                <form method="post" action="technician_actions.php" style="display:inline;" onsubmit="return confirm('Delete this technician? This cannot be undone.');">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="technician_id" value="<?php echo $t['id']; ?>">
                  <input type="hidden" name="action" value="delete">
                  <button type="submit" class="table-icon-btn del" title="Delete"><?php echo panel_icon('trash'); ?></button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <p style="font-size:12px;color:var(--ink-400);margin-top:14px;">Showing <?php echo count($technicians); ?> of <?php echo $totalTechnicians; ?> technicians · <a href="technicians.php" style="color:var(--blue-900);font-weight:700;">View all &rarr;</a></p>
      <?php endif; ?>
    </div>
  </div>

  <div>
    <div class="side-card">
      <div class="side-card-head"><h3><?php echo panel_icon('plus'); ?> Add Technician</h3></div>
      <form method="post" action="technician_actions.php">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="action" value="add">

        <label class="field-label" style="margin-top:0;">Full name</label>
        <input class="field-input" name="name" required placeholder="Enter full name">

        <label class="field-label">Email address</label>
        <input class="field-input" type="email" name="email" required placeholder="Enter email address">

        <label class="field-label">Contact number</label>
        <input class="field-input" name="phone" placeholder="Enter contact number">

        <label class="field-label">Password</label>
        <input class="field-input" type="password" name="password" required placeholder="Enter password">

        <label class="field-label">Specialty</label>
        <input class="field-input" name="specialty" placeholder="e.g. Aircon Specialist">

        <label class="field-label">Service area</label>
        <input class="field-input" name="service_area" placeholder="e.g. Biñan, Laguna">

        <label class="field-label">Services offered</label>
        <div class="service-pick">
          <?php foreach ($services as $s): ?>
            <label class="service-opt">
              <input type="checkbox" name="service_ids[]" value="<?php echo $s['id']; ?>" style="display:inline;">
              <?php echo htmlspecialchars($s['name']); ?>
            </label>
          <?php endforeach; ?>
        </div>

        <button type="submit" class="btn-primary btn-block btn-save" style="margin-top:16px;"><?php echo panel_icon('check-circle'); ?><span>Save Technician</span></button>
      </form>
    </div>

    <div class="side-card">
      <div class="side-card-head"><h3><?php echo panel_icon('chart'); ?> Technicians Summary</h3></div>
      <div class="donut" style="background:conic-gradient(var(--green-600) 0deg <?php echo $donutDeg; ?>deg, var(--line) <?php echo $donutDeg; ?>deg 360deg);">
        <div class="donut-center"><div class="n"><?php echo $totalTechnicians; ?></div><div class="l">Total</div></div>
      </div>
      <div class="legend-row"><span class="legend-dot" style="background:var(--green-600);"></span><span class="lbl">Active</span><span class="val"><?php echo $activeTechCount; ?></span><span class="pct"><?php echo $activePct; ?>%</span></div>
      <div class="legend-row"><span class="legend-dot" style="background:var(--line);"></span><span class="lbl">Inactive</span><span class="val"><?php echo $inactiveTechCount; ?></span><span class="pct"><?php echo $inactivePct; ?>%</span></div>
    </div>
  </div>
</div>

<?php require __DIR__ . '/../includes/panel_footer.php'; ?>

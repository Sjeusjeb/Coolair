<?php
require __DIR__ . '/../config/session.php';
require __DIR__ . '/../config/supabase.php';
require __DIR__ . '/../config/security.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}
csrf_verify();
$adminId = $_SESSION['admin_id'];

$bookingId = (int)($_POST['booking_id'] ?? 0);
$action = $_POST['action'] ?? '';

if ($action === 'cancel' && $bookingId) {
    sb_update('bookings', ['id' => sb_eq($bookingId)], ['status' => 'cancelled']);
    sb_insert('booking_status_log', ['booking_id' => $bookingId, 'status' => 'cancelled']);
    sb_insert('admin_activity_log', ['admin_id' => $adminId, 'action' => 'cancel_booking', 'details' => "Cancelled booking #$bookingId"]);
    header('Location: bookings.php?msg=' . urlencode('Booking cancelled.'));
    exit;
}

header('Location: bookings.php');
exit;

<?php
require __DIR__ . '/../config/session.php';
require __DIR__ . '/../config/supabase.php';
require __DIR__ . '/../config/security.php';

$BASE = '../';
$pageTitle = 'Admin Login';
$error = '';

if (isset($_SESSION['admin_id'])) {
    header('Location: dashboard.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    $lockedUntil = login_is_locked('admin', $email);
    if ($lockedUntil) {
        $error = 'Too many failed attempts. Please try again after ' . date('g:i A', strtotime($lockedUntil)) . '.';
    } else {
        $admin = sb_get_one('admins', ['email' => sb_eq($email)]);

        if ($admin && password_verify($password, $admin['password'])) {
            login_reset('admin', $email);
            session_regenerate_id(true);
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_name'] = $admin['name'];

            sb_insert('admin_activity_log', ['admin_id' => $admin['id'], 'action' => 'login', 'details' => 'Logged in']);

            header('Location: dashboard.php');
            exit;
        }
        login_record_failure('admin', $email);
        $error = 'Incorrect email or password.';
    }
}

require __DIR__ . '/../includes/header.php';
?>

<div class="login-wrap">
  <div class="card">
    <h2 style="margin-bottom:4px;">Admin login</h2>
    <p style="font-size:13px;color:var(--ink-600);margin-bottom:20px;">Manage technicians, bookings, and customer accounts.</p>

    <?php if ($error): ?><div class="error-box"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

    <form method="post">
      <?php echo csrf_field(); ?>
      <label class="field-label" style="margin-top:0;">Email</label>
      <input class="field-input" type="email" name="email" required value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">

      <label class="field-label">Password</label>
      <input class="field-input" type="password" name="password" required>

      <button type="submit" class="btn-primary btn-block" style="margin-top:18px;">Log in</button>
    </form>

  </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>

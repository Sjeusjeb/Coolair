<?php
require __DIR__ . '/../config/session.php';
require __DIR__ . '/../config/supabase.php';

if (isset($_SESSION['admin_id'])) {
    sb_insert('admin_activity_log', ['admin_id' => $_SESSION['admin_id'], 'action' => 'logout', 'details' => 'Logged out']);
}

unset($_SESSION['admin_id'], $_SESSION['admin_name']);
header('Location: login.php');
exit;

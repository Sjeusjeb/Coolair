<?php
require __DIR__ . '/../config/session.php';
require __DIR__ . '/../config/supabase.php';
require __DIR__ . '/../config/security.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}
csrf_verify();
$adminId = $_SESSION['admin_id'];

function log_admin_action(int $adminId, string $action, string $details): void
{
    sb_insert('admin_activity_log', ['admin_id' => $adminId, 'action' => $action, 'details' => $details]);
}

$action = $_POST['action'] ?? '';

if ($action === 'add') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $specialty = trim($_POST['specialty'] ?? '');
    $years = (int)($_POST['years_experience'] ?? 0);
    $area = trim($_POST['service_area'] ?? '');
    $fee = (float)($_POST['starting_fee'] ?? 0);
    $initials = strtoupper(trim($_POST['avatar_initials'] ?? '')) ?: strtoupper(substr($name, 0, 2));
    $serviceIds = $_POST['service_ids'] ?? [];

    if ($name === '' || $email === '' || $password === '') {
        header('Location: technicians.php?err=' . urlencode('Name, email, and password are required.'));
        exit;
    }
    if (strlen($password) < 8) {
        header('Location: technicians.php?err=' . urlencode('Password must be at least 8 characters.'));
        exit;
    }

    $existing = sb_get_one('technicians', ['email' => sb_eq($email)]);
    if ($existing) {
        header('Location: technicians.php?err=' . urlencode('A technician with that email already exists.'));
        exit;
    }

    $colors = ['#0F4C75', '#3ABEFF', '#F5A623', '#1F9D6B'];
    $color = $colors[array_rand($colors)];
    $hash = password_hash($password, PASSWORD_DEFAULT);

    $tech = sb_insert('technicians', [
        'name' => $name, 'email' => $email, 'password' => $hash, 'specialty' => $specialty,
        'years_experience' => $years, 'service_area' => $area, 'starting_fee' => $fee,
        'avatar_initials' => $initials, 'avatar_color' => $color,
        'is_verified' => false, 'background_checked' => false, 'rating' => 0, 'review_count' => 0,
        'distance_km' => 0, 'availability' => 'available_now',
    ]);
    $techId = $tech['id'];

    if ($serviceIds) {
        $rows = [];
        foreach ($serviceIds as $sid) {
            $rows[] = ['technician_id' => $techId, 'service_id' => (int)$sid];
        }
        sb_insert_many('technician_services', $rows);
    }

    log_admin_action($adminId, 'add_technician', "Added technician: $name ($email)");
    header('Location: technicians.php?msg=' . urlencode('Technician added.'));
    exit;
}

if ($action === 'edit_services') {
    $id = (int)($_POST['technician_id'] ?? 0);
    $serviceIds = $_POST['service_ids'] ?? [];

    $tech = sb_get_one('technicians', ['id' => sb_eq($id)]);
    if (!$tech) {
        header('Location: technicians.php?err=' . urlencode('Technician not found.'));
        exit;
    }

    // Replace the full set: clear existing links, then insert whatever's now checked.
    sb_delete('technician_services', ['technician_id' => sb_eq($id)]);

    if ($serviceIds) {
        $rows = [];
        foreach ($serviceIds as $sid) {
            $rows[] = ['technician_id' => $id, 'service_id' => (int)$sid];
        }
        sb_insert_many('technician_services', $rows);
    }

    log_admin_action($adminId, 'edit_services', "Updated services offered for technician #$id ({$tech['name']})");
    header('Location: technicians.php?msg=' . urlencode('Services updated for ' . $tech['name'] . '.'));
    exit;
}

if ($action === 'toggle_verified') {
    $id = (int)($_POST['technician_id'] ?? 0);
    sb_rpc('toggle_technician_verified', ['p_technician_id' => $id]);
    log_admin_action($adminId, 'toggle_verified', "Toggled verification for technician #$id");
    header('Location: technicians.php?msg=' . urlencode('Verification status updated.'));
    exit;
}

if ($action === 'delete') {
    $id = (int)($_POST['technician_id'] ?? 0);
    // Bookings reference this technician, so remove those first (technician_services and
    // booking_status_log rows cascade automatically via their foreign keys)
    sb_delete('bookings', ['technician_id' => sb_eq($id)]);
    sb_delete('technicians', ['id' => sb_eq($id)]);
    log_admin_action($adminId, 'delete_technician', "Deleted technician #$id");
    header('Location: technicians.php?msg=' . urlencode('Technician deleted.'));
    exit;
}

header('Location: technicians.php');
exit;

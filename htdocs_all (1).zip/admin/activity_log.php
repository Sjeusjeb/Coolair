<?php
require __DIR__ . '/../config/session.php';
require __DIR__ . '/../config/supabase.php';

$BASE = '../';
$pageTitle = 'Activity Log';

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

$logs = sb_get('admin_activity_log', [
    'select' => '*,admins(name)',
    'order'  => 'created_at.desc',
    'limit'  => 100,
]);
foreach ($logs as &$l) {
    $l['admin_name'] = $l['admins']['name'] ?? '';
}
unset($l);

$nowIso = date('c');
$lockouts = sb_get('login_throttle', [
    'locked_until' => 'not.is.null',
    'order'        => 'locked_until.desc',
]);
// PostgREST can't compare a column against now() directly, so filter here
$lockouts = array_values(array_filter($lockouts, function ($l) use ($nowIso) {
    return $l['locked_until'] && strtotime($l['locked_until']) > strtotime($nowIso);
}));

require __DIR__ . '/../includes/header.php';
?>

<a href="dashboard.php" class="btn-secondary" style="display:inline-block;margin-bottom:18px;">&larr; Dashboard</a>
<h2 style="margin-bottom:4px;">Activity &amp; security log</h2>
<p style="font-size:13px;color:var(--ink-600);margin-bottom:22px;">Recent admin actions and any accounts currently locked out from repeated failed logins.</p>

<?php if (!empty($lockouts)): ?>
<div class="card">
  <h3>Currently locked out</h3>
  <?php foreach ($lockouts as $l): ?>
    <div class="req-row">
      <div class="req-body">
        <div class="req-name"><?php echo htmlspecialchars($l['email']); ?> (<?php echo htmlspecialchars($l['role']); ?>)</div>
        <div class="req-meta">Locked until <?php echo date('g:i A, M j', strtotime($l['locked_until'])); ?></div>
      </div>
    </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<div class="card">
  <h3>Recent admin actions</h3>
  <?php if (empty($logs)): ?>
    <p class="empty-note">No activity recorded yet.</p>
  <?php endif; ?>
  <?php foreach ($logs as $l): ?>
    <div class="req-row">
      <div class="req-body">
        <div class="req-name"><?php echo htmlspecialchars($l['admin_name']); ?> — <?php echo htmlspecialchars(str_replace('_', ' ', $l['action'])); ?></div>
        <div class="req-meta"><?php echo htmlspecialchars($l['details']); ?></div>
      </div>
      <div class="req-meta"><?php echo date('g:i A, M j', strtotime($l['created_at'])); ?></div>
    </div>
  <?php endforeach; ?>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>

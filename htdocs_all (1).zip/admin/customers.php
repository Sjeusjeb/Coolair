<?php
require __DIR__ . '/../config/session.php';
require __DIR__ . '/../config/supabase.php';

$BASE = '../';
$pageTitle = 'Customers';

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

$customers = sb_rpc('customers_with_booking_counts');

require __DIR__ . '/../includes/header.php';
?>

<a href="dashboard.php" class="btn-secondary" style="display:inline-block;margin-bottom:18px;">&larr; Dashboard</a>
<h2 style="margin-bottom:18px;">Customers (<?php echo count($customers); ?>)</h2>

<div class="card">
  <?php if (empty($customers)): ?>
    <p class="empty-note">No customer accounts yet.</p>
  <?php endif; ?>
  <?php foreach ($customers as $c): ?>
    <div class="req-row">
      <div class="req-body">
        <div class="req-name"><?php echo htmlspecialchars($c['name']); ?></div>
        <div class="req-meta"><?php echo htmlspecialchars($c['email']); ?> <?php echo $c['phone'] ? '· ' . htmlspecialchars($c['phone']) : ''; ?></div>
        <div class="req-meta">Joined <?php echo date('M j, Y', strtotime($c['created_at'])); ?></div>
      </div>
      <span class="tag"><?php echo (int)$c['booking_count']; ?> booking<?php echo (int)$c['booking_count'] === 1 ? '' : 's'; ?></span>
    </div>
  <?php endforeach; ?>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>

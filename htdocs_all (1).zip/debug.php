<?php
// TEMPORARY diagnostic page. Delete this file after use.
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo 'PHP ' . PHP_VERSION . '<br>';
echo 'curl: ' . (function_exists('curl_init') ? 'ok' : 'MISSING') . '<br>';

$cred = __DIR__ . '/config/supabase_credentials.php';
if (!is_file($cred)) {
    echo 'credentials file: MISSING (upload config/supabase_credentials.php)';
    exit;
}
echo 'credentials file: found<br>';

$src = file_get_contents($cred);
try {
    token_get_all($src, TOKEN_PARSE);
    echo 'credentials syntax: ok<br>';
} catch (ParseError $e) {
    echo 'credentials syntax ERROR on line ' . (int)$e->getLine()
       . ' - check the quotes and the semicolon at the end of that line.';
    exit;
}

if (strpos($src, 'PASTE_NEW_SECRET_KEY_HERE') !== false) {
    echo 'secret key: NOT SET YET (still the placeholder)';
    exit;
}

try {
    require __DIR__ . '/config/supabase.php';
    if (strpos(SUPABASE_SERVICE_KEY, 'sb_secret_') !== 0 && strpos(SUPABASE_SERVICE_KEY, 'eyJ') !== 0) {
        echo 'secret key: does not look like a secret key (it should start with sb_secret_)<br>';
    }
    sb_request('GET', 'services?select=id&limit=1');
    echo 'Supabase: OK';
} catch (Throwable $e) {
    echo 'Error: ' . htmlspecialchars($e->getMessage());
}

<?php
// Supabase project credentials.
// DO NOT commit this file to a public repo / DO NOT expose it to the browser.

define('SUPABASE_URL', 'https://mqgaxtaabwyqlaokhewq.supabase.co');

// SECRET key (sb_secret_...). Server-side only. Bypasses RLS, which is what
// this PHP backend needs. Paste the NEW key from Supabase Dashboard ->
// Project Settings -> API Keys here.
define('SUPABASE_SERVICE_KEY', 'PASTE_NEW_SECRET_KEY_HERE');

// Publishable key (sb_publishable_...). Safe for browsers but subject to RLS.
// Not used by this backend; kept here for reference.
define('SUPABASE_PUBLISHABLE_KEY', 'sb_publishable_rQWaqhHkKMiX0KUu8OnvaA_YwFDNbC_');

<?php
// ================================================================
// Lightweight REST client for Supabase (PostgREST), replacing the old
// PDO/MySQL connection. Every function here talks to:
//   https://<project>.supabase.co/rest/v1/<table or rpc/<fn>>
// using the service_role key, which is safe here because this file
// only ever runs server-side (never sent to the browser).
//
// Every other file in the app now does:
//   require __DIR__ . '/config/supabase.php';
// instead of requiring config/db.php, and calls sb_get()/sb_insert()/
// sb_update()/sb_delete()/sb_upsert()/sb_rpc()/sb_count() below instead
// of building SQL with $pdo.
// ================================================================

$__sbCreds = __DIR__ . '/supabase_credentials.php';
if (!is_file($__sbCreds)) {
    http_response_code(503);
    error_log('CoolAir: config/supabase_credentials.php is missing.');
    exit('Service is temporarily unavailable. (Server configuration is incomplete.)');
}
require $__sbCreds;

class SupabaseException extends RuntimeException {}

// Any uncaught database/API error becomes a friendly 503 page instead of a
// blank HTTP 500. The real reason is written to the server error log, and
// shown by debug.php (delete that file once everything works).
set_exception_handler(function (Throwable $e) {
    error_log('CoolAir uncaught: ' . $e->getMessage());
    if (!headers_sent()) { http_response_code(503); }
    echo '<!DOCTYPE html><meta charset="utf-8"><title>Unavailable</title>'
       . '<div style="font-family:sans-serif;max-width:480px;margin:15vh auto;text-align:center;">'
       . '<h2>Something went wrong</h2><p>The service is temporarily unavailable. Please try again in a moment.</p></div>';
});

/**
 * Low-level request to the PostgREST endpoint. Returns ['body' => array|null, 'headers' => array].
 */
function sb_request(string $method, string $path, $body = null, array $extraHeaders = []): array
{
    $url = rtrim(SUPABASE_URL, '/') . '/rest/v1/' . ltrim($path, '/');

    $headers = array_merge([
        'apikey: ' . SUPABASE_SERVICE_KEY,
        'Authorization: Bearer ' . SUPABASE_SERVICE_KEY,
        'Content-Type: application/json',
    ], $extraHeaders);

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_CUSTOMREQUEST  => $method,
        CURLOPT_HTTPHEADER     => $headers,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HEADER         => true,
        CURLOPT_TIMEOUT        => 15,
    ]);
    if ($body !== null) {
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
    }

    $response = curl_exec($ch);
    if ($response === false) {
        $err = curl_error($ch);
        curl_close($ch);
        throw new SupabaseException('Supabase request failed: ' . $err);
    }

    $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    $status     = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $rawHeaders = substr($response, 0, $headerSize);
    $rawBody    = substr($response, $headerSize);

    $respHeaders = [];
    foreach (explode("\r\n", $rawHeaders) as $line) {
        if (strpos($line, ':') !== false) {
            [$k, $v] = explode(':', $line, 2);
            $respHeaders[strtolower(trim($k))] = trim($v);
        }
    }

    $decoded = $rawBody !== '' ? json_decode($rawBody, true) : null;

    if ($status >= 400) {
        $msg = is_array($decoded) && isset($decoded['message']) ? $decoded['message'] : $rawBody;
        throw new SupabaseException("Supabase error ($status) on $method $path: " . $msg);
    }

    return ['body' => $decoded, 'headers' => $respHeaders];
}

/**
 * Build a PostgREST query string from an assoc array of already-formatted
 * filter values, e.g. ['id' => 'eq.5', 'select' => '*', 'order' => 'created_at.desc'].
 */
function sb_qs(array $params): string
{
    return $params ? ('?' . http_build_query($params)) : '';
}

/** SELECT rows from a table. $params example: ['select' => '*', 'email' => 'eq.foo@bar.com', 'order' => 'created_at.desc', 'limit' => 8] */
function sb_get(string $table, array $params = []): array
{
    $params += ['select' => '*'];
    $res = sb_request('GET', $table . sb_qs($params));
    return $res['body'] ?? [];
}

/** SELECT a single row (first match), or null if none found. */
function sb_get_one(string $table, array $params = []): ?array
{
    $params['limit'] = 1;
    $rows = sb_get($table, $params);
    return $rows[0] ?? null;
}

/** Exact row count for a table (with optional filters), via the Content-Range header. */
function sb_count(string $table, array $filters = []): int
{
    $params = $filters + ['select' => 'id'];
    $res = sb_request('GET', $table . sb_qs($params), null, [
        'Prefer: count=exact',
        'Range: 0-0',
    ]);
    $range = $res['headers']['content-range'] ?? '';
    // format: "0-0/123"  or  "*/0" when empty
    if (strpos($range, '/') !== false) {
        [, $total] = explode('/', $range);
        return $total === '*' ? 0 : (int)$total;
    }
    return count($res['body'] ?? []);
}

/** INSERT one row. Returns the inserted row (with generated id) as an assoc array. */
function sb_insert(string $table, array $data): array
{
    $res = sb_request('POST', $table, $data, ['Prefer: return=representation']);
    $body = $res['body'] ?? [];
    return $body[0] ?? [];
}

/** INSERT multiple rows at once. Returns the inserted rows. */
function sb_insert_many(string $table, array $rows): array
{
    $res = sb_request('POST', $table, $rows, ['Prefer: return=representation']);
    return $res['body'] ?? [];
}

/** UPSERT (insert, or update on conflict). $onConflict is the unique column name(s), e.g. "role,email". */
function sb_upsert(string $table, array $data, string $onConflict): array
{
    $path = $table . sb_qs(['on_conflict' => $onConflict]);
    $res = sb_request('POST', $path, $data, [
        'Prefer: resolution=merge-duplicates,return=representation',
    ]);
    $body = $res['body'] ?? [];
    return $body[0] ?? [];
}

/** UPDATE rows matching $filters (e.g. ['id' => 'eq.5']) with $data. Returns updated rows. */
function sb_update(string $table, array $filters, array $data): array
{
    $res = sb_request('PATCH', $table . sb_qs($filters), $data, ['Prefer: return=representation']);
    return $res['body'] ?? [];
}

/** DELETE rows matching $filters. */
function sb_delete(string $table, array $filters): void
{
    sb_request('DELETE', $table . sb_qs($filters));
}

/** Call a Postgres function (RPC). Returns the decoded JSON result (array of rows for RETURNS TABLE). */
function sb_rpc(string $fn, array $params = [])
{
    $res = sb_request('POST', 'rpc/' . $fn, (object)$params);
    return $res['body'] ?? [];
}

/** eq. filter shorthand, e.g. sb_eq(5) -> "eq.5" */
function sb_eq($value): string
{
    return 'eq.' . $value;
}

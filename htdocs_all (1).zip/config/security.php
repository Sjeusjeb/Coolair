<?php
// Security helpers: CSRF tokens + login throttling (lockout after repeated
// failed logins). Requires config/session.php to already be included
// (session must be started) and config/supabase.php to already be required.

// ---------------------------------------------------------------
// CSRF protection
// ---------------------------------------------------------------
function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars(csrf_token()) . '">';
}

// Call at the top of every POST handler. Stops and shows a plain message
// if the token is missing or doesn't match (e.g. an old cached form, or a
// forged cross-site request).
function csrf_verify(): void
{
    $submitted = $_POST['csrf_token'] ?? '';
    if (empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $submitted)) {
        http_response_code(403);
        die('Security check failed (invalid or expired form). Please go back, refresh the page, and try again.');
    }
}

// ---------------------------------------------------------------
// Login throttling — locks out an email+role after repeated failed
// attempts, for a short cooldown period.
// ---------------------------------------------------------------
const LOGIN_MAX_ATTEMPTS = 5;
const LOGIN_LOCK_MINUTES = 10;

function login_is_locked(string $role, string $email): ?string
{
    $row = sb_get_one('login_throttle', [
        'role'  => sb_eq($role),
        'email' => sb_eq($email),
    ]);
    if ($row && !empty($row['locked_until']) && strtotime($row['locked_until']) > time()) {
        return $row['locked_until'];
    }
    return null;
}

function login_record_failure(string $role, string $email): void
{
    $row = sb_get_one('login_throttle', [
        'role'  => sb_eq($role),
        'email' => sb_eq($email),
    ]);

    $newCount = ($row['fail_count'] ?? 0) + 1;
    $lockedUntil = null;
    if ($newCount >= LOGIN_MAX_ATTEMPTS) {
        $lockedUntil = date('c', time() + LOGIN_LOCK_MINUTES * 60);
        $newCount = 0; // reset counter once locked, so it starts fresh after the lock expires
    }

    sb_upsert('login_throttle', [
        'role'         => $role,
        'email'        => $email,
        'fail_count'   => $newCount,
        'locked_until' => $lockedUntil,
    ], 'role,email');
}

function login_reset(string $role, string $email): void
{
    sb_delete('login_throttle', [
        'role'  => sb_eq($role),
        'email' => sb_eq($email),
    ]);
}

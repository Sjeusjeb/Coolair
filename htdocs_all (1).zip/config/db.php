<?php
// Database connection settings.
// Default XAMPP MySQL credentials: user "root", empty password.
// Change these if your setup is different.

$DB_HOST = 'localhost';
$DB_NAME = 'coolair';
$DB_USER = 'root';
$DB_PASS = '';

try {
    $pdo = new PDO(
        "mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $e) {
    die('Database connection failed: ' . htmlspecialchars($e->getMessage()) .
        '<br>Make sure XAMPP\'s MySQL is running and that you ran database/schema.sql and database/seed.php.');
}

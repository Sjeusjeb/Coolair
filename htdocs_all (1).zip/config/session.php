<?php
// Centralized, hardened session bootstrap.
// Every page includes this instead of calling session_start() directly.

if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.use_strict_mode', 1);
    ini_set('session.cookie_httponly', 1);
    ini_set('session.cookie_samesite', 'Lax');
    // If the site is ever served over HTTPS, uncomment the next line:
    // ini_set('session.cookie_secure', 1);
    session_start();
}

// Basic security headers (harmless on plain XAMPP/local use, useful if deployed)
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('Referrer-Policy: strict-origin-when-cross-origin');

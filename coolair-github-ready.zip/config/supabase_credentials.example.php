<?php
// Copy this file to config/supabase_credentials.php and fill in your own values.
// The real file is git-ignored. NEVER commit real keys to a public repo.

define('SUPABASE_URL', 'https://YOUR-PROJECT-REF.supabase.co');

// SECRET key (sb_secret_...). Server-side only. Bypasses RLS.
define('SUPABASE_SERVICE_KEY', 'sb_secret_REPLACE_ME');

// Publishable key (sb_publishable_...). Safe for browsers, subject to RLS.
define('SUPABASE_PUBLISHABLE_KEY', 'sb_publishable_REPLACE_ME');
